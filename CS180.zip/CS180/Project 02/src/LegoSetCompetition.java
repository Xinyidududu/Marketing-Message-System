import java.util.Scanner;

public class LegoSetCompetition {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int playerOneTotalNum = 0;
        int playerTwoTotalNum = 0;
        int roundNum = 0;
        int day = 0;
        boolean startPlay = true;
        boolean startPlay2 = true;
        String finishedLegoName1 = "";
        String notFinish1 = "";
        String finishedLegoName2 = "";
        String notFinish2 = "";
        System.out.println("Welcome to the Lego Set Competition!");


        do {
            int totalLegoNumber = 0;
            int playerOneNumber = 0;
            int playerTwoNumber = 0;
            //Use a scanner to collect the names of the three lego sets and the number of pieces in each of them.
            System.out.println("Enter the name of Lego Set 1");
            String nameLegoOne = scan.nextLine();
            System.out.println("Enter the number of pieces in Lego Set 1");
            int numberLegoOne = scan.nextInt();
            scan.nextLine();
            System.out.println("Enter the name of Lego Set 2");
            String nameLegoTwo = scan.nextLine();
            System.out.println("Enter the number of pieces in Lego Set 2");
            int numberLegoTwo = scan.nextInt();
            scan.nextLine();
            System.out.println("Enter the name of Lego Set 3");
            String nameLegoThree = scan.nextLine();
            System.out.println("Enter the number of pieces in Lego Set 3");
            int numberLegoThree = scan.nextInt();
            totalLegoNumber = numberLegoThree + numberLegoTwo + numberLegoOne;
            scan.nextLine();

            do {
                day++;
                System.out.printf("Enter the number of pieces player 1 used for building on day %d\n", day);
                int playerOneRoundNum = scan.nextInt();
                System.out.printf("Enter the number of pieces player 2 used for building on day %d\n", day);
                int playerTwoRoundNum = scan.nextInt();
                scan.nextLine();

                playerOneNumber += playerOneRoundNum;
                playerOneTotalNum += playerOneRoundNum;
                playerTwoNumber += playerTwoRoundNum;
                playerTwoTotalNum += playerTwoRoundNum;

                if (totalLegoNumber - playerOneNumber <= 0 && totalLegoNumber - playerTwoNumber <= 0) {
                    finishedLegoName1 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree + ", ";
                    finishedLegoName2 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree + ", ";
                    System.out.println("The competition ended in a tie! There will be a tiebreaker round");
                    System.out.println(finishedLegoName1);
                    break;
                }


                if (playerOneNumber - totalLegoNumber >= 0 && playerTwoNumber - totalLegoNumber < 0) {
                    finishedLegoName1 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree;
                    notFinish1 += "None";
                    System.out.println("Congratulations to player 1 for winning the Lego Set Competition!");
                    System.out.println("Additional information about the competition results is below");
                    if (playerTwoNumber <= numberLegoOne) {
                        if (roundNum < 1) {
                            finishedLegoName2 += "None";
                        }
                        notFinish2 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree;
                    } else if (playerTwoNumber <= numberLegoTwo) {
                        finishedLegoName2 += nameLegoOne;
                        notFinish2 += nameLegoOne;
                    } else {
                        finishedLegoName2 += nameLegoOne + ", " + nameLegoTwo;
                        notFinish2 += nameLegoThree;
                    }
                    CompetitionLog competitionLog1 = new CompetitionLog(1, finishedLegoName1, notFinish1,
                            playerOneTotalNum);
                    CompetitionLog competitionLog2 = new CompetitionLog(2, finishedLegoName2, notFinish2,
                            playerTwoTotalNum);
                    System.out.print(competitionLog1);
                    System.out.print(competitionLog2);
                    System.out.println("The competition lasted " + day + " days");
                    startPlay2 = false;
                    startPlay = false;
                } else if (playerTwoNumber - totalLegoNumber >= 0 && playerOneNumber - totalLegoNumber < 0) {
                    finishedLegoName2 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree;
                    notFinish2 += "None";
                    System.out.println("Congratulations to player 2 for winning the Lego Set Competition!");
                    System.out.println("Additional information about the competition results is below");

                    if (playerOneNumber <= numberLegoOne) {
                        if (roundNum < 1) {
                            finishedLegoName1 += "None";
                        }
                        notFinish1 += nameLegoOne + ", " + nameLegoTwo + ", " + nameLegoThree;
                    } else if (playerTwoNumber <= numberLegoTwo) {
                        finishedLegoName1 += nameLegoOne;
                        notFinish1 += nameLegoOne;
                    } else {
                        finishedLegoName1 += nameLegoOne + ", " + nameLegoTwo;
                        notFinish1 += nameLegoThree;
                    }

                    CompetitionLog competitionLog1 = new CompetitionLog(1, finishedLegoName1, notFinish1,
                            playerOneTotalNum);
                    CompetitionLog competitionLog2 = new CompetitionLog(2, finishedLegoName2, notFinish2,
                            playerTwoTotalNum);
                    System.out.print(competitionLog1);
                    System.out.print(competitionLog2);
                    System.out.println("The competition lasted " + day + " days");
                    startPlay2 = false;
                    startPlay = false;
                }


            } while (startPlay2);
            roundNum++;
        } while (startPlay);
    }


}

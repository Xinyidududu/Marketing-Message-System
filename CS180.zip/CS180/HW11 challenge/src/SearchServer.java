import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class SearchServer {

    public static void main(String[] args) {
        try {
            boolean searchAgain = true;
            ServerSocket serverSocket = new ServerSocket(4242);
            Socket socket = serverSocket.accept();
            BufferedReader bfr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter ptw = new PrintWriter(socket.getOutputStream());
            while (searchAgain) {
                String input = bfr.readLine(); //user's first input
                //System.out.println("user's first input: " + input);
                ArrayList<String> allIndex = findTitlesContaining(input);
                ptw.println(allIndex);
                ptw.flush();

                int again;
                if (allIndex.size() != 0) {
                    String realInput = bfr.readLine(); //user actually choose a word
                    String description = findDescription(realInput);
                    ptw.println(description);
                    ptw.flush();
                }

                String againNumb = bfr.readLine();
                again = Integer.parseInt(againNumb);
                if (again == 1) {
                    searchAgain = false;
                }
            }


            bfr.close();
            ptw.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<String> findTitlesContaining(String keyword) throws IOException {
        ArrayList<String> allIndex = new ArrayList<>();
        File file = new File("searchDatabase");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] content = line.split(";");
            String index = content[0];
            String title = content[1];
            String info = content[2];
            if (title.toLowerCase().contains(keyword.toLowerCase())
                    || info.toLowerCase().contains(keyword.toLowerCase())) {
                allIndex.add(index);
            }else {
                break;
            }
        }
        return allIndex;
    }

    public static String findDescription(String keyword) throws IOException {
        //System.out.println("get the title: " + keyword);
        File file = new File("searchDatabase");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        String descirption = "";
        while ((line = br.readLine()) != null) {
            //System.out.println("4" + line);
            String[] content = line.split(";");
            String info = content[2];
            if (line.contains(keyword)) {
                descirption = info;
            }else {
                break;
            }
        }
        br.close();
        //System.out.println("description: " + descirption);
        return descirption;
    }


}

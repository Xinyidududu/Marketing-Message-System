public class Maze {
    private boolean[][] maze;
    private int playerRow;
    private int playerColumn;
    private int treasureRow;
    private int treasureColumn;

    public Maze(boolean[][] maze, int treasureRow, int treasureColumn) {
        this.maze = maze;
        this.treasureRow = treasureRow;
        this.treasureColumn = treasureColumn;
        this.playerRow = 0;
        this.playerColumn = 0;
    }

    public boolean[][] getMaze() {
        return maze;
    }

    public void setMaze(boolean[][] maze) {
        this.maze = maze;
    }

    public int getPlayerRow() {
        return playerRow;
    }

    public void setPlayerRow(int playerRow) {
        this.playerRow = playerRow;
    }

    public int getPlayerColumn() {
        return playerColumn;
    }

    public void setPlayerColumn(int playerColumn) {
        this.playerColumn = playerColumn;
    }

    public int getTreasureRow() {
        return treasureRow;
    }

    public void setTreasureRow(int treasureRow) {
        this.treasureRow = treasureRow;
    }

    public int getTreasureColumn() {
        return treasureColumn;
    }

    public void setTreasureColumn(int treasureColumn) {
        this.treasureColumn = treasureColumn;
    }

    public boolean checkWin() {
        return (this.playerRow == this.treasureRow && this.playerColumn == this.treasureColumn);
    }
}

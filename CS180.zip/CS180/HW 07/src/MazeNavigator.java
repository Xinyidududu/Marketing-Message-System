import java.util.Scanner;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Fall 2022</p>
 *
 * @author Purdue CS
 * @version August 22, 2022
 */
public class MazeNavigator {

    public static final String WELCOME = "Welcome to the Maze Navigator!";
    public static final String INITIALIZE_MAZE = "Initializing maze...";
    public static final String MAZE_DIMENSIONS = "Please enter the maze dimensions:";
    public static final String MAZE_VALUES = "Please enter the values for the maze's row %d:";
    public static final String TREASURE_LOCATION = "Please enter the expected treasure location:";
    public static final String READY = "Ready to start?";
    public static final String CURRENT_POSITION = "Player's Position: %d,%d";
    public static final String MOVE_SELECT = "Please enter a move:";
    public static final String[] MOVES = {"Up", "Down", "Left", "Right"};
    public static final String INVALID_MOVE = "Invalid move! Select another direction.";
    public static final String TREASURE_FOUND = "Treasure found!";
    public static final String FAREWELL = "Thank you for playing!";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean startPlay = true;
        boolean playProcess = true;
        System.out.println(WELCOME);
        System.out.println(INITIALIZE_MAZE);
        System.out.println(MAZE_DIMENSIONS);
        String mazePosition = scanner.nextLine();
        String[] comma = mazePosition.split(",");
        int row = Integer.parseInt(comma[0]);
        int col = Integer.parseInt(comma[1]);
        boolean[][] mazeDimensions = new boolean[row][col];
        for (int k = 0; k < row; k++) {
            System.out.printf(MAZE_VALUES + "\n", k);
            String rowStatus = scanner.nextLine();
            String[] expectComma = rowStatus.split(",");
            for (int h = 0; h < col; h++) {
                boolean enterStatus = Boolean.parseBoolean(expectComma[h]);
                mazeDimensions[k][h] = enterStatus;
            }
        }
        System.out.println(TREASURE_LOCATION);
        String treasureLoc = scanner.nextLine();
        String[] treasurePlace = treasureLoc.split(",");
        int treasureRow = Integer.parseInt(treasurePlace[0]);
        int treasureCol = Integer.parseInt(treasurePlace[1]);
        Maze maze = new Maze(mazeDimensions, treasureRow, treasureCol);
        while (startPlay) {
            System.out.println(READY);
            String ifPlay = scanner.nextLine();
            if (ifPlay.equalsIgnoreCase("No")) {
                System.out.println(FAREWELL);
                startPlay = false;
            } else {
                while (playProcess) {
                    System.out.printf(CURRENT_POSITION + "\n", maze.getPlayerRow(), maze.getPlayerColumn());
                    System.out.println(MOVE_SELECT);
                    System.out.println("1. " + MOVES[0]);
                    System.out.println("2. " + MOVES[1]);
                    System.out.println("3. " + MOVES[2]);
                    System.out.println("4. " + MOVES[3]);
                    String enterDirection = scanner.nextLine();
                    if (enterDirection.equalsIgnoreCase("Up")) {
                        if (maze.getPlayerRow() == 0
                                && mazeDimensions[mazeDimensions.length - 1][maze.getPlayerColumn()]) {
                            maze.setPlayerRow(mazeDimensions.length - 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        } else if (maze.getPlayerRow() == 0
                                && !mazeDimensions[mazeDimensions.length - 1][maze.getPlayerColumn()]) {
                            System.out.println(INVALID_MOVE);
                        } else if (!mazeDimensions[maze.getPlayerRow() - 1][maze.getPlayerColumn()]) {
                            System.out.println(INVALID_MOVE);
                        } else {
                            maze.setPlayerRow(maze.getPlayerRow() - 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        }
                    } else if (enterDirection.equalsIgnoreCase("Down")) {
                        if (maze.getPlayerRow() == mazeDimensions.length - 1
                                && !mazeDimensions[0][maze.getPlayerColumn()]) {
                            System.out.println(TREASURE_FOUND);
                        } else if (maze.getPlayerRow() == mazeDimensions.length - 1
                                && mazeDimensions[0][maze.getPlayerColumn()]) {
                            maze.setPlayerRow(0);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        } else if (!mazeDimensions[maze.getPlayerRow() + 1][maze.getPlayerColumn()]) {
                            System.out.println(INVALID_MOVE);
                        } else {
                            maze.setPlayerRow(maze.getPlayerRow() + 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        }
                    } else if (enterDirection.equalsIgnoreCase("Left")) {
                        if (maze.getPlayerColumn() - 1 < 0
                                && !mazeDimensions[maze.getPlayerRow()][mazeDimensions[0].length - 1]) {
                            System.out.println(INVALID_MOVE);
                        } else if (maze.getPlayerColumn() - 1 < 0
                                && mazeDimensions[maze.getPlayerRow()][mazeDimensions[0].length - 1]) {
                            maze.setPlayerColumn(mazeDimensions[0].length - 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        } else if (!mazeDimensions[maze.getPlayerRow()][maze.getPlayerColumn() - 1]) {
                            System.out.println(INVALID_MOVE);
                        } else {
                            maze.setPlayerColumn(maze.getPlayerColumn() - 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        }
                    } else if (enterDirection.equalsIgnoreCase("Right")) {
                        if (maze.getPlayerColumn() + 1 > mazeDimensions[0].length - 1
                                && !mazeDimensions[maze.getPlayerRow()][0]) {
                            System.out.println(INVALID_MOVE);
                        } else if (maze.getPlayerColumn() + 1 > mazeDimensions[0].length - 1
                                && mazeDimensions[maze.getPlayerRow()][0]) {
                            maze.setPlayerColumn(0);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        } else if (!mazeDimensions[maze.getPlayerRow()][maze.getPlayerColumn() + 1]) {
                            System.out.println(INVALID_MOVE);
                        } else {
                            maze.setPlayerColumn(maze.getPlayerColumn() + 1);
                            if (maze.checkWin()) {
                                System.out.println(TREASURE_FOUND);
                                System.out.println(FAREWELL);
                                playProcess = false;
                                startPlay = false;
                            }
                        }
                    }
                }
            }
        }
    }
}



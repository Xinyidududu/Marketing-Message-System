class B extends A {

    int k;

    int l;

    public void display() {

        System.out.println(k);

    }

}



import java.util.ArrayList;

public class MyThread {
    public static void main(String[] args) {
        String hello = "Hello";

        String world = " World!";

        String both = hello + world;

        String substr = both.substring(1, 3) + both.substring(5);
        System.out.println(substr);
    }


}


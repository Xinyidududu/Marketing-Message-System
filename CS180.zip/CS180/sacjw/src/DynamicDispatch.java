import java.io.*;

class DynamicDispatch {

    public static void main(String[] args) {

        try {

            BufferedReader buf = new BufferedReader(new FileReader(new File("a.txt")));}

        catch (IOException e) {

            System.out.println("This is a problem");

        } catch (FileNotFoundException e) {

            System.out.println("And this is a different problem");

        }

    }

}



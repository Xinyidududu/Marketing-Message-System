class A {

    int i;

    int j;

    public void display() {

        System.out.println(i);

    }

}
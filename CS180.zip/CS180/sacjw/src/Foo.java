public class Foo {
    public void foo() throws Exception {

        try {

            throw new Exception("Foo throws exception!");

        } catch (Exception ex) {



        }

    }
}

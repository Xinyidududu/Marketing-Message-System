class Student {

    String name;

    int age = 19;

    Student(String name, int age){

        this.name = name;

        this.age = age;

    }

}


public class MyClass {

    public void myMethod() throws Exception {

        System.out.print("myMethod ");

        throw new Exception("exceptionMessage");

    }



    public MyClass() {

        System.out.print("Constructor ");

    }



    public static void main(String[] args) {

        int i = 42;

        switch(i){

            case (22):

                System.out.println("Hello from the other side");



            case (32):

                System.out.println("Do you want to know what love is?");

                break;



            case (42):

                if(!(i >= 42)) {

                    System.out.println("Jackie Robinson day!");

                } else {

                    System.out.println("I prefer Roberto Clemente");

                }



            default:

                System.out.println("In the end");

                break;

        }

    }

}
public class callFoo {
    public void callFoo() {

        try {

            foo();

        } catch (Exception ex) {



        }


    }
    public void foo() throws Exception {

        try {

            throw new Exception("Foo throws exception!");

        } catch (Exception ex) {



        }

    }
    public static void main(String[] agrs){
        System.out.println("1");
        
    }

}



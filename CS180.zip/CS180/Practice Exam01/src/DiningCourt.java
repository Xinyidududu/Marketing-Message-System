public class DiningCourt {
    private Entree firstEntree;
    private Entree secondEntree;
    private Entree thirdEntree;

    public DiningCourt(Entree firstEntree, Entree secondEntree, Entree thirdEntree) {
        this.firstEntree = firstEntree;
        this.secondEntree = secondEntree;
        this.thirdEntree = thirdEntree;
    }

    public DiningCourt(DiningCourt diningCourt) {
        this.firstEntree = diningCourt.firstEntree;
        this.secondEntree = diningCourt.secondEntree;
        this.thirdEntree = diningCourt.thirdEntree;
    }

    public DiningCourt() {
        this.firstEntree = null;
        this.secondEntree = null;
        this.thirdEntree = null;
    }

    public Entree getFirstEntree() {
        return firstEntree;
    }

    public Entree getSecondEntree() {
        return secondEntree;
    }

    public Entree getThirdEntree() {
        return thirdEntree;
    }

    public void setFirstEntree(Entree firstEntree) {
        this.firstEntree = firstEntree;
    }

    public void setSecondEntree(Entree secondEntree) {
        this.secondEntree = secondEntree;
    }

    public void setThirdEntree(Entree thirdEntree) {
        this.thirdEntree = thirdEntree;
    }

    public Entree getLowestCalorieEntree() {
        Entree getLowest = null;
        if (firstEntree.getCalories() < secondEntree.getCalories()
                && secondEntree.getCalories() < thirdEntree.getCalories()) {
            getLowest = firstEntree;
        }
        if (firstEntree.getCalories() > secondEntree.getCalories()
                && secondEntree.getCalories() > thirdEntree.getCalories()) {
            getLowest = thirdEntree;
        }
        if (firstEntree.getCalories() > secondEntree.getCalories()
                && secondEntree.getCalories() < thirdEntree.getCalories()) {
            getLowest = secondEntree;
        }
        return getLowest;
    }

    public Entree getHighestCalorieEntree() {
        Entree getHighest = null;
        if (firstEntree.getCalories() < secondEntree.getCalories()
                && secondEntree.getCalories() < thirdEntree.getCalories()) {
            getHighest = thirdEntree;
        }
        if (firstEntree.getCalories() > secondEntree.getCalories()
                && secondEntree.getCalories() > thirdEntree.getCalories()) {
            getHighest = firstEntree;
        }
        if (firstEntree.getCalories() < secondEntree.getCalories()
                && secondEntree.getCalories() > thirdEntree.getCalories()) {
            getHighest = secondEntree;
        }
        return getHighest;
    }

    public void printVegetarianEntrees() {
        if (firstEntree.isVegetarian() && !secondEntree.isVegetarian() && !thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + firstEntree.getName());
        }
        if (!firstEntree.isVegetarian() && !secondEntree.isVegetarian() && thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + thirdEntree.getName());
        }
        if (!firstEntree.isVegetarian() && secondEntree.isVegetarian() && !thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + secondEntree.getName());
        }
        if (firstEntree.isVegetarian() && secondEntree.isVegetarian() && !thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + secondEntree.getName());
        }
        if (!firstEntree.isVegetarian() && secondEntree.isVegetarian() && thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + secondEntree.getName());
            System.out.println("Option 1: " + thirdEntree.getName());
        }
        if (firstEntree.isVegetarian() && !secondEntree.isVegetarian() && thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + thirdEntree.getName());
        }
        if (!firstEntree.isVegetarian() && !secondEntree.isVegetarian() && !thirdEntree.isVegetarian()) {
            System.out.println("No vegetarian options are available :(");
        }
        if (firstEntree.isVegetarian() && secondEntree.isVegetarian() && thirdEntree.isVegetarian()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + secondEntree.getName());
            System.out.println("Option 2: " + thirdEntree.getName());
        }
    }

    public void printVeganEntrees() {
        if (firstEntree.isVegan() && !secondEntree.isVegan() && !thirdEntree.isVegan()) {
            System.out.println("Option 0: " + firstEntree.getName());
        }
        if (!firstEntree.isVegan() && !secondEntree.isVegan() && thirdEntree.isVegan()) {
            System.out.println("Option 0: " + thirdEntree.getName());
        }
        if (!firstEntree.isVegan() && secondEntree.isVegan() && !thirdEntree.isVegan()) {
            System.out.println("Option 0: " + secondEntree.getName());
        }
        if (firstEntree.isVegan() && secondEntree.isVegan() && !thirdEntree.isVegan()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + secondEntree.getName());
        }
        if (!firstEntree.isVegan() && secondEntree.isVegan() && thirdEntree.isVegan()) {
            System.out.println("Option 0: " + secondEntree.getName());
            System.out.println("Option 1: " + thirdEntree.getName());
        }
        if (firstEntree.isVegan() && !secondEntree.isVegan() && thirdEntree.isVegan()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + thirdEntree.getName());
        }
        if (!firstEntree.isVegan() && !secondEntree.isVegan() && !thirdEntree.isVegan()) {
            System.out.println("No vegan options are available :(");
        }
        if (firstEntree.isVegan() && secondEntree.isVegan() && thirdEntree.isVegan()) {
            System.out.println("Option 0: " + firstEntree.getName());
            System.out.println("Option 1: " + secondEntree.getName());
            System.out.println("Option 2: " + thirdEntree.getName());
        }
    }

    public String toString() {
        return "DiningCourt<=firstEntree=" + firstEntree.toString() + ", secondEntree=" + secondEntree.toString()
                + ", thirdEntree=" + thirdEntree.toString() + ">";
    }

}


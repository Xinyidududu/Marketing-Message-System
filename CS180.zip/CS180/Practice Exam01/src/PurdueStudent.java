public class PurdueStudent {
    private String firstName;
    private String lastName;
    private int age;
    private String major;
    private String studentType;
    private String homeCountry;
    private String homeTown;

    public PurdueStudent(String firstName, String lastName, int age, String major, String studentType,
                         String homeCountry, String homeTown) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.major = major;
        this.studentType = studentType;
        this.homeCountry = homeCountry;
        this.homeTown = homeTown;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String getMajor() {
        return major;
    }

    public String getStudentType() {
        return studentType;
    }

    public String getHomeCountry() {
        return homeCountry;
    }

    public String getHomeTown() {
        return homeTown;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setStudentType(String studentType) {
        this.studentType = studentType;
    }

    public void setHomeCountry(String homeCountry) {
        this.homeCountry = homeCountry;
    }

    public void setHomeTown(String homeTown) {
        this.homeTown = homeTown;
    }

    @Override
    public String toString() {
        return "PurdueStudent<" +
                "firstName=" + firstName +
                ", lastName=" + lastName +
                ", age=" + age +
                ", major=" + major +
                ", studentType=" + studentType +
                ", homeCountry=" + homeCountry +
                ", homeTown=" + homeTown +
                ">";
    }
}

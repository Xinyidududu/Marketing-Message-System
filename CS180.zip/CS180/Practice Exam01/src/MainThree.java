public class MainThree {
    private MainTwo firstEntree;
    private MainTwo secondEntree;
    private MainTwo thirdEntree;

    public MainThree(MainTwo firstEntree, MainTwo secondEntree, MainTwo thirdEntree) {
        this.firstEntree = firstEntree;
        this.secondEntree = secondEntree;
        this.thirdEntree = thirdEntree;
    }

    public MainThree(MainThree mainThree) {
        this.firstEntree = mainThree.firstEntree;
        this.secondEntree = mainThree.secondEntree;
        this.thirdEntree = mainThree.thirdEntree;
    }

    public MainThree() {
        this.firstEntree = null;
        this.secondEntree = null;
        this.thirdEntree = null;
    }

    public MainTwo getFirstEntree() {
        return firstEntree;
    }

    public void setFirstEntree(MainTwo firstEntree) {
        this.firstEntree = firstEntree;
    }

    public MainTwo getSecondEntree() {
        return secondEntree;
    }

    public void setSecondEntree(MainTwo secondEntree) {
        this.secondEntree = secondEntree;
    }

    public MainTwo getThirdEntree() {
        return thirdEntree;
    }

    public void setThirdEntree(MainTwo thirdEntree) {
        this.thirdEntree = thirdEntree;
    }

    public MainTwo getLowestCalorieEntree() {
        MainTwo lowest = null;
        if (firstEntree.getCalories() > secondEntree.getCalories()
                && firstEntree.getCalories() > thirdEntree.getCalories()) {
            lowest = thirdEntree;
        }
        if (firstEntree.getCalories() < secondEntree.getCalories() &&
                secondEntree.getCalories() < thirdEntree.getCalories()) {
            lowest = firstEntree;
        }
        if (firstEntree.getCalories() > secondEntree.getCalories()
                && secondEntree.getCalories() < thirdEntree.getCalories()) {
            lowest = secondEntree;
        }

        return lowest;
    }
}

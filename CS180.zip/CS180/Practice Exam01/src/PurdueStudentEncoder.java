import java.util.Scanner;

public class PurdueStudentEncoder {

    public static void main(String[] args) {
        String totalName = "";
        String newTotalName;
        String trackName;
        String identify;
        String status = "";
        char upper;
        char nextUpper;
        String creditStatus;
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to the Purdue University Student Encoder!");
        System.out.println("What is the student's first and last name?");
        String fullName = scan.nextLine();
        fullName = fullName.trim();
        int blank = fullName.indexOf(" ");

        System.out.println("How many credits has the student taken prior to this semester?");
        int creditsPre = scan.nextInt();
        if (creditsPre < 30) {
            status = "Freshmen";
        } else if (creditsPre >= 30 && creditsPre < 60) {
            status = "Sophomore";
        } else if (creditsPre >= 60 && creditsPre < 90) {
            status = "Junior";
        } else if (creditsPre >= 90) {
            status = "Senior";
        }
        System.out.println("How many tracks are you on?");
        int trackNum = scan.nextInt();
        System.out.println(trackNum);
        for (int i = 1; i <= trackNum; i++) {
            System.out.printf("What is the name of track number %d?" + "\n", i);
            trackName = scan.next();
            scan.nextLine();
            totalName = totalName + trackName + ",";
        }
        System.out.println("What is the student's home country?");
        String home = scan.nextLine();
        if (home.equalsIgnoreCase("USA") || home.equalsIgnoreCase("United States of America")) {
            identify = "DOMES";
        } else {
            identify = "INTER";
        }
        System.out.println("What is the student's hometown?");
        String homeTown = scan.nextLine();
        System.out.println("What is the student's major?");
        String major = scan.nextLine();
        System.out.println("How many credits is the student taking this semester?");
        int credits = scan.nextInt();
        if (credits >= 12) {
            creditStatus = "FT";
        } else {
            creditStatus = "PT";
        }
        newTotalName = totalName.substring(0, totalName.length() - 1);
        upper = fullName.toUpperCase().charAt(0);
        if (blank == -1) {
            System.out.println(upper + "_" + status + "_" + newTotalName + "_" + identify + ":" + homeTown + "_" + major
                    + "_" + creditStatus + ":" + credits + ";");
        } else {
            nextUpper = fullName.toUpperCase().charAt(blank + 1);

            System.out.println(upper + "" + nextUpper + "_" + status + "_" + newTotalName + "_" + identify + ":"
                    + homeTown + "_" + major
                    + "_" + creditStatus + ":" + credits + ";");
        }
    }
}

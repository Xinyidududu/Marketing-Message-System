import java.util.Scanner;

public class Shopkeeper {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String enterName = "What is the customer's name?";
        String enterIdem = "How many items did the customer purchase?";
        String enterIdemName = "Enter the %s item name.";
        String enterCost = "How much did this item cost?";
        boolean enterList = true;
        int idemCode = 0;
        double totalCost = 0;
        char outputName1;
        char outputName2;
        String eachIdemName;
        String totalName = "";
        int blank;
        System.out.println(enterName);
        String fullName = scan.nextLine();
        System.out.println(enterIdem);
        int idemNumber = scan.nextInt();
        scan.nextLine();

        while (enterList) {
            idemCode++;
            if (idemCode == 1) {
                System.out.printf(enterIdemName + "\n", idemCode + "st");

            }
            if (idemCode == 2) {
                System.out.printf(enterIdemName + "\n", idemCode + "nd");

            }
            if (idemCode == 3) {
                System.out.printf(enterIdemName + "\n", idemCode + "rd");

            }
            if (idemCode > 3) {
                System.out.printf(enterIdemName + "\n", idemCode + "th");

            }
            eachIdemName = scan.next();
            System.out.println(enterCost);
            double eachCost = scan.nextDouble();
            totalCost = totalCost + eachCost;

            totalName = totalName +eachIdemName + ",";

            if (idemCode == idemNumber) {
                enterList = false;
            }

        }
        totalName = totalName.substring(0,totalName.length()-1);
        fullName = fullName.trim();
        blank = fullName.indexOf(" ");
        outputName1 = fullName.toUpperCase().charAt(0);
        if (blank == -1) {
            System.out.printf("Your customer string is " + outputName1 + idemNumber +
                    totalName + ":%.2f" + "\n", totalCost);
        } else {
            outputName2 = fullName.toUpperCase().charAt(blank + 1);
            System.out.printf("Your customer string is " + outputName1 + outputName2 + idemNumber +
                    totalName + ":%.2f" + "\n", totalCost);

        }

    }


}
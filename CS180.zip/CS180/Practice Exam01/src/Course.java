import java.util.Objects;

public class Course {
    private PurdueStudent studentOne;
    private PurdueStudent studentTwo;
    private PurdueStudent studentThree;

    public Course(PurdueStudent studentOne, PurdueStudent studentTwo, PurdueStudent studentThree) {
        this.studentOne = studentOne;
        this.studentTwo = studentTwo;
        this.studentThree = studentThree;
    }

    public Course(Course course) {
        this.studentOne = course.studentOne;
        this.studentTwo = course.studentTwo;
        this.studentThree = course.studentThree;
    }

    public boolean enrollStudent(PurdueStudent student) {
        if (studentOne.getAge() == 0 || studentOne.getFirstName() == null || studentOne.getLastName() == null
                || studentOne.getStudentType() == null || studentOne.getHomeCountry() == null ||
                studentOne.getHomeTown() == null || studentOne.getMajor() == null) {
            studentOne = student;
            return true;
        } else if (studentTwo.getAge() == 0 || studentTwo.getFirstName() == null || studentTwo.getLastName() == null
                || studentTwo.getStudentType() == null || studentTwo.getHomeCountry() == null ||
                studentTwo.getHomeTown() == null || studentTwo.getMajor() == null) {
            studentTwo = student;
            return true;
        } else if (studentThree.getAge() == 0 || studentThree.getFirstName() == null
                || studentThree.getLastName() == null
                || studentThree.getStudentType() == null || studentThree.getHomeCountry() == null ||
                studentThree.getHomeTown() == null || studentThree.getMajor() == null) {
            studentThree = student;
            return true;
        } else {
            return false;
        }
    }


    public boolean dropStudent(PurdueStudent student) {
        if (Objects.equals(studentOne.getFirstName(), student.getFirstName())) {
            studentOne.setFirstName(null);
            return true;
        } else if (Objects.equals(studentOne.getLastName(), student.getLastName())) {
            studentOne.setLastName(null);
            return true;
        } else if (Objects.equals(studentTwo.getLastName(), student.getLastName())) {
            studentTwo.setLastName(null);
            return true;
        } else if (Objects.equals(studentTwo.getFirstName(), student.getFirstName())) {
            studentOne.setFirstName(null);
            return true;
        } else if (Objects.equals(studentThree.getLastName(), student.getLastName())) {
            studentThree.setLastName(null);
            return true;
        } else if (Objects.equals(studentThree.getFirstName(), student.getFirstName())) {
            studentThree.setFirstName(null);
            return true;
        } else {
            return false;
        }

    }

    public int getAvailableSeats() {
        int nullFields = 0;
        if (studentOne.getFirstName() == null) {
            nullFields++;
        }
        if (studentOne.getLastName() == null) {
            nullFields++;
        }
        if (studentOne.getAge() == 0) {
            nullFields++;
        }
        if (studentOne.getStudentType() == null) {
            nullFields++;
        }
        if (studentOne.getHomeCountry() == null) {
            nullFields++;
        }
        if (studentOne.getHomeTown() == null) {
            nullFields++;
        }
        if (studentOne.getMajor() == null) {
            nullFields++;

        }
        if (studentThree.getFirstName() == null) {
            nullFields++;
        }
        if (studentThree.getLastName() == null) {
            nullFields++;
        }
        if (studentThree.getAge() == 0) {
            nullFields++;
        }
        if (studentThree.getStudentType() == null) {
            nullFields++;
        }
        if (studentThree.getHomeCountry() == null) {
            nullFields++;
        }
        if (studentThree.getHomeTown() == null) {
            nullFields++;
        }
        if (studentThree.getMajor() == null) {
            nullFields++;
        }

        if (studentTwo.getFirstName() == null) {
            nullFields++;
        }
        if (studentTwo.getLastName() == null) {
            nullFields++;
        }
        if (studentTwo.getAge() == 0) {
            nullFields++;
        }
        if (studentTwo.getStudentType() == null) {
            nullFields++;
        }
        if (studentTwo.getHomeCountry() == null) {
            nullFields++;
        }
        if (studentTwo.getHomeTown() == null) {
            nullFields++;
        }
        if (studentTwo.getMajor() == null) {
            nullFields++;
        }
        return nullFields;
    }

    public int getNumEnrolled() {
        int nonNullFields = 0;
        if (studentOne.getFirstName() != null) {
           nonNullFields++;
        }
        if (studentOne.getLastName() != null) {
            nonNullFields++;
        }
        if (studentOne.getAge() != 0) {
            nonNullFields++;
        }
        if (studentOne.getStudentType() != null) {
            nonNullFields++;
        }
    if (studentOne.getHomeCountry() != null) {
        nonNullFields++;
        }
        if (studentOne.getHomeTown() != null) {
            nonNullFields++;
        }
        if (studentOne.getMajor() != null) {
            nonNullFields++;

        }
        if (studentThree.getFirstName() != null) {
            nonNullFields++;
        }
        if (studentThree.getLastName() != null) {
            nonNullFields++;
        }
        if (studentThree.getAge() != 0) {
            nonNullFields++;
        }
        if (studentThree.getStudentType() != null) {
            nonNullFields++;
        }
        if (studentThree.getHomeCountry() != null) {
            nonNullFields++;
        }
        if (studentThree.getHomeTown() != null) {
            nonNullFields++;
        }
        if (studentThree.getMajor() != null) {
            nonNullFields++;
        }

        if (studentTwo.getFirstName() != null) {
            nonNullFields++;
        }
        if (studentTwo.getLastName() != null) {
            nonNullFields++;
        }
        if (studentTwo.getAge() != 0) {
            nonNullFields++;
        }
        if (studentTwo.getStudentType() != null) {
            nonNullFields++;
        }
        if (studentTwo.getHomeCountry() != null) {
            nonNullFields++;
        }
        if (studentTwo.getHomeTown() != null) {
            nonNullFields++;
        }
        if (studentTwo.getMajor() != null) {
            nonNullFields++;
        }
        return nonNullFields;

    }
}

public class MainTwo {
    private String name;
    private int calories;
    private boolean vegetarian;
    private boolean vegan;

    public MainTwo(String name, int calories, boolean vegetarian, boolean vegan) {
        this.name = name;
        this.calories = calories;
        this.vegetarian = vegetarian;
        this.vegan = vegan;
    }
    public MainTwo (MainTwo mainTwo){
        this.name = mainTwo.name;
        this.calories = mainTwo.calories;
        this.vegetarian = mainTwo.vegetarian;
        this.vegan = mainTwo.vegan;
    }
    public MainTwo(){
        this.name = null;
        this.calories = 0;
        this.vegan= false;
        this.vegetarian= false;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public boolean isVegetarian() {
        return vegetarian;
    }

    public void setVegetarian(boolean vegetarian) {
        this.vegetarian = vegetarian;
    }

    public boolean isVegan() {
        return vegan;
    }

    public void setVegan(boolean vegan) {
        this.vegan = vegan;
    }

    @Override
    public String toString() {
        return "MainTwo<" +
                "name=" + name +
                ", calories=" + calories +
                ", vegetarian=" + vegetarian +
                ", vegan=" + vegan +
                ">";
    }
}

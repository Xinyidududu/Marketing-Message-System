import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        boolean startAsk = true;
        String totalItemName = "";
        String newTotalName;
        double totalCost = 0;
        int index = 0;
        Scanner scan = new Scanner(System.in);
        System.out.println("What is the customer's name?");
        String fullName = scan.nextLine();
        int blank = fullName.indexOf(" ");

        System.out.println("How many items did the customer purchase?");
        int itemsNum = scan.nextInt();

        while (startAsk) {
            index++;
            if (index == 1) {
                System.out.printf("Enter the %d st item name.\n", index);
            }
            if (index == 2) {
                System.out.printf("Enter the %d nd item name.\n", index);
            }
            if (index == 3) {
                System.out.printf("Enter the %d rd item name.\n", index);
            }
            if (index > 3) {
                System.out.printf("Enter the %d th item name.\n", index);
            }
            String eachName = scan.next();
            System.out.println("How much did this item cost?");
            double eachCost = scan.nextDouble();
            totalItemName = totalItemName + eachName + ",";
            totalCost = totalCost + eachCost;
            if (index == itemsNum) {
                startAsk = false;
            }
        }
        newTotalName = totalItemName.substring(0, totalItemName.length() - 1);
        char upper = fullName.toUpperCase().charAt(0);
        if (blank == -1) {
            System.out.printf("Your customer string is " + upper + itemsNum + newTotalName + ": %.2f\n", totalCost);
        } else {
            char nextUpper = fullName.toUpperCase().charAt(blank + 1);
            System.out.printf("Your customer string is" + upper + nextUpper +
                    itemsNum + newTotalName + ": %.2f\n", totalCost);

        }
    }
}

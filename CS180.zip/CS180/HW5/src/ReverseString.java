import java.util.Scanner;



public class ReverseString {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean again;

        do {
            System.out.println("Enter a string:");
            String input = scanner.nextLine();

            for (int i = 0; i < input.length(); i++) {
                char reverse = input.charAt(input.length() - (i + 1));
                System.out.print(reverse);

            }


            System.out.println("\nAgain?");
            String answerAgain = scanner.nextLine();
            if (answerAgain.equals("Y")){
                again = true;
            }else {
                again = false;
            }
        } while (again);

    }
}

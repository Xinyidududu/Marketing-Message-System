import java.util.Scanner;

/**
 * A  program.
 * <p>
 * Purdue University -- CS18000 -- Spring 2022 -- Homework 05 -- Challenge
 *
 * @author Purdue CS
 * @version January 10, 2021
 */
public class CollatzConjecture {
    public static void main(String[] args) {
        String welcome = "Welcome to Collatz Conjecture Calculator!";
        String optionOne = "1. Calculate with upper limit";
        String optionTwo = "2. Calculate until the end";
        String initialNumPrompt = "Enter the starting number:";
        String upperLimitPrompt = "Enter the upper limit:";
        String result = "Operation performed %d times, and the resulting number is %d.";
        String unfinishedPrompt = "Do you want to continue the calculations %d more times? (yes/no)";
        String againPrompt = "Do you want to use the calculator again? (yes/no)";
        String farewellPrompt = "Thanks for using Collatz Conjecture Calculator!";

        Scanner scanner = new Scanner(System.in);
        System.out.println(welcome);

        boolean keep;

        do {
            keep = true;
            boolean keepCalculating = true;
            String firstOption;
            String keepInput;
            int firstNumPrompt;
            int upLimitPrompt;
            int countNumb = 0;

            // user input
            System.out.println(optionOne);

            System.out.println(optionTwo);
            firstOption = scanner.next();

            // checking for valid input
            while (Integer.parseInt(firstOption) != 1 && Integer.parseInt(firstOption) != 2) {
                System.out.println(optionOne);

                System.out.println(optionTwo);

                firstOption = scanner.next();
            }

            // option 1 execution
            if (Integer.parseInt(firstOption) == 1) {
                System.out.print(initialNumPrompt);
                System.out.print('\n');
                firstNumPrompt = scanner.nextInt();
                System.out.println(upperLimitPrompt);

                upLimitPrompt = scanner.nextInt();

                do {
                    String newString = "";
                    newString += firstNumPrompt;
                    int temp = upLimitPrompt - 1;
                    do {
                        newString += "...";
                        if (firstNumPrompt % 2 == 0) {
                            firstNumPrompt /= 2;
                            temp--;
                            newString += firstNumPrompt;
                            countNumb++;
                        } else {
                            firstNumPrompt = firstNumPrompt * 3 + 1;
                            temp--;
                            newString += firstNumPrompt;
                            countNumb++;
                        }
                    } while (!(temp <= 0 || firstNumPrompt <= 1));
                    newString += "!";
                    System.out.println(newString);

                    System.out.printf(result + "\n", countNumb, firstNumPrompt);

                    if (firstNumPrompt >= 1) {
                        if (firstNumPrompt > 1) {
                            System.out.printf(unfinishedPrompt + "\n", upLimitPrompt);
                            keepInput = scanner.next();

                            if (keepInput.equals("no")) {
                                keepCalculating = false;
                            }
                        } else {
                            keepCalculating = false;
                        }
                    }
                } while (keepCalculating);

                // option 2 execution
            } else {
                String newString = "";
                System.out.println(initialNumPrompt);

                firstNumPrompt = scanner.nextInt();
                newString += firstNumPrompt;
                do {
                    newString += "...";
                    if (firstNumPrompt % 2 == 0) {
                        firstNumPrompt /= 2;
                        newString += firstNumPrompt;
                        countNumb++;
                    } else {
                        firstNumPrompt = firstNumPrompt * 3 + 1;
                        newString += firstNumPrompt;
                        countNumb++;
                    }
                } while (firstNumPrompt != 1);
                newString += "!";
                System.out.println(newString);

                System.out.printf(result + "\n", countNumb, firstNumPrompt);
            }

            // Asking user if they want to continue
            System.out.println(againPrompt);

            keepInput = scanner.next();

            if (keepInput.equals("yes")) {
                keep = true;
            } else if (keepInput.equals("no")) {
                keep = false;
            }
        } while (keep);
        System.out.println(farewellPrompt);

    }
}






import java.util.Scanner;

public class colla {
    public static void main(String[] args) {
        String welcome = "Welcome to Collatz Conjecture Calculator!";
        String optionOne = "1. Calculate with upper limit";
        String optionTwo = "2. Calculate until the end";
        String initialNumPrompt = "Enter the starting number:";
        String upperLimitPrompt = "Enter the upper limit:";
        String result = "Operation performed %d times, and the resulting number is %d.";
        String unfinishedPrompt = "Do you want to continue the calculations %d more times? (yes/no)";
        String againPrompt = "Do you want to use the calculator again? (yes/no)";
        String farewellPrompt = "Thanks for using Collatz Conjecture Calculator!";

        Scanner scanner = new Scanner(System.in);


        boolean startAsk = true;
        boolean startCalculate = true;
        int firstOption;
        String runAgain;
        int initialNum;
        int upperLimitNum = 0;
        String unfinishedAns;
        int counter = 0;
        String newString = "";
        System.out.println(welcome);

        do {

            System.out.println(optionOne);
            System.out.println(optionTwo);
            firstOption = scanner.nextInt();

            while (!(firstOption == 1 || firstOption == 2)) {
                System.out.println(optionOne);
                System.out.println(optionTwo);
                firstOption = scanner.nextInt();
            }

            System.out.println(initialNumPrompt);
            initialNum = scanner.nextInt();
            newString += initialNum;

            // option 1 calculation
            if (firstOption == 1) {
                System.out.println(upperLimitPrompt);
                upperLimitNum = scanner.nextInt();

                while (startCalculate) {
                    newString += "...";
                    if (initialNum % 2 == 0) {
                        initialNum = initialNum / 2;
                        newString += initialNum;
                        counter += 1;
                        if (counter >= upperLimitNum - 1 || initialNum == 1) {
                            startCalculate = false;
                        }
                    } else if (initialNum % 2 == 1) {
                        initialNum = initialNum * 3 + 1;
                        newString += initialNum;
                        counter += 1;
                        if (counter >= upperLimitNum - 1 || initialNum == 1) {
                            startCalculate = false;
                        }

                    }

                }
                do {
                    System.out.println(newString + "!");
                    System.out.printf(result + "\n", counter, initialNum);
                    System.out.printf(unfinishedPrompt + "\n", upperLimitNum);
                    unfinishedAns = scanner.next();
                    scanner.nextLine();
                    if (unfinishedAns.equalsIgnoreCase("yes") && counter >= upperLimitNum - 1) {
                        for (int i = 0; i < upperLimitNum + 1; i++) {
                            if (initialNum % 2 == 0) {
                                initialNum = initialNum / 2;
                                newString += initialNum;
                                counter += 1;
                                if (counter >= upperLimitNum - 1 || initialNum == 1) {
                                    break;
                                }
                            } else if (initialNum % 2 == 1) {
                                initialNum = initialNum * 3 + 1;
                                newString += initialNum;
                                counter += 1;
                                if (counter >= upperLimitNum - 1 || initialNum == 1) {
                                    break;
                                }
                            }
                        }
                    } else {
                        break;
                    }
                } while (counter >= upperLimitNum - 1);

            } else {
                while (startCalculate) {
                    newString += "...";
                    if (initialNum % 2 == 0) {
                        initialNum = initialNum / 2;
                        newString += initialNum;
                        counter += 1;
                        if (initialNum == 1) {
                            startCalculate = false;
                        }
                    } else if (initialNum % 2 == 1) {
                        initialNum = (initialNum * 3) + 1;
                        newString += initialNum;
                        counter += 1;
                        if (initialNum == 1) {
                            startCalculate = false;
                        }
                    }
                }
                System.out.println(newString + "!");
                System.out.printf(result + "\n", counter, initialNum);
            }

            System.out.println(againPrompt);
            runAgain = scanner.next();
            if (runAgain.equalsIgnoreCase("NO")) {
                startAsk = false;
            } else if (runAgain.equalsIgnoreCase("yes")) {
                startAsk = true;
            }


        } while (startAsk);
        System.out.println(farewellPrompt);

    }
}


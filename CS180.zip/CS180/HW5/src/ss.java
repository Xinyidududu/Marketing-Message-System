public class ss {
    public static void main(String[] args)  {
        int a = 3;
        int i;
        System.out.println(a);
        for(i = 0; i <= 3; i++) {
            a += 1;
        }
        System.out.println(a);
    }
}

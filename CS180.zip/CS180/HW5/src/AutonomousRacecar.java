import java.util.Random;
import java.util.Scanner;

public class AutonomousRacecar {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int speed = 0;
        int seedValue;
        int newRandom;
        int threshold;
        String newString = "";
        Boolean run = true;


        System.out.println("Please enter the seed for the random number generator:");
        seedValue = scan.nextInt();

        System.out.println("Please enter the threshold:");
        threshold = scan.nextInt();
        scan.nextLine();
        Random random = new Random(seedValue);

        while (run) {
            speed += 5;
            newString = newString + speed + "...";
            newRandom = random.nextInt((threshold * 10)) + 1;
            if (newRandom >= threshold) {
                continue;
            } else {
                run = false;
            }

        }

        System.out.println("Starting the car...");
        System.out.print("Current speed: " + newString + "Done!");


        System.out.println("\nMaximum run speed: " + speed);


    }
}
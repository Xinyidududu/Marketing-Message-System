import java.util.Scanner;
/**
 * A CollatzConjecture program.
 *
 * Purdue University -- CS18000 -- Spring 2022 -- Homework 05 -- Debugging
 *
 * @author JuefuLi_Lab10
 * @version January 10, 2021
 */
public class Main {
    public static void main(String[] args) {
        String welcome = "Welcome to Collatz Conjecture Calculator!";
        String optionOne = "1. Calculate with upper limit";
        String optionTwo = "2. Calculate until the end";
        String initialNumPrompt = "Enter the starting number:";
        String upperLimitPrompt = "Enter the upper limit:";
        String result = "Operation performed %d times, and the resulting number is %d.";
        String unfinishedPrompt = "Do you want to continue the calculations %d more times? (yes/no)";
        String againPrompt = "Do you want to use the calculator again? (yes/no)";
        String farewellPrompt = "Thanks for using Collatz Conjecture Calculator!";

        Scanner scanner = new Scanner(System.in);

        // TODO: Implement your solution below
        int answer;
        System.out.println(welcome);

        String answer4 = "yes";
        while(answer4.equals("yes")){
            do {
                System.out.println(optionOne);
                System.out.println(optionTwo);
                answer = scanner.nextInt();
                scanner.nextLine();
            }while(answer > 2);
            if (answer == 1){
                System.out.println(initialNumPrompt);
                int number = scanner.nextInt();
                scanner.nextLine();
                System.out.println(upperLimitPrompt);
                int upperLimit = scanner.nextInt();
                scanner.nextLine();
                int num = 0;
                while(num < upperLimit - 1){
                    if (number % 2 != 0){
                        System.out.print(number+"...");
                        number = (number * 3) + 1;
                        num++;
                    } else {
                        System.out.print(number + "...");
                        number = number / 2;
                        num++;
                    }
                    if (number == 1){
                        System.out.print(number);
                        System.out.println("!");
                        System.out.println("Operation performed " + num + " times, and the resulting number is " + number + ".");
                        break;
                    }

                }
                if(number != 1){
                    System.out.print(number);
                    System.out.println("!");
                    System.out.println("Operation performed " + num + " times, and the resulting number is " + number + ".");
                    System.out.println("Do you want to continue the calculations 5 more times? (yes/no)");
                    String answer2 = scanner.nextLine();
                    if(answer2.equals("yes")){
                        int i;
                        for (i = 0;i < 4;i++){
                            if(number%2 != 0){
                                System.out.print(number + "...");
                                number = (number * 3) + 1;
                                num++;
                            } else {
                                System.out.print(number+"...");
                                number = number/2;
                                num++;
                            }
                            if(number == 1){
                                System.out.print(number);
                                System.out.println("!");
                                System.out.println("Operation performed " + num + " times, and the resulting number is " + number+".");
                                break;
                            }
                        }
                        if(number != 1){
                            System.out.print(number);
                            System.out.println("!");
                            System.out.println("Operation performed " + num + " times, and the resulting number is " + number + ".");
                            System.out.println("Do you want to continue the calculations 5 more times? (yes/no)");
                            String answer3 = scanner.nextLine();
                        }
                    }


                }

                System.out.println(againPrompt);
                answer4 = scanner.nextLine();

            } else if (answer == 2) {
                System.out.println(initialNumPrompt);
                int number = scanner.nextInt();
                scanner.nextLine();
                int num = 0;
                while(number != 1){
                    if(number % 2 != 0){
                        System.out.print(number+"...");
                        number = (number * 3) + 1;
                        num++;
                    } else {
                        System.out.print(number + "...");
                        number = number / 2;
                        num++;
                    }
                }
                System.out.print(number);
                System.out.println("!");
                System.out.println("Operation performed " + num + " times, and the resulting number is " + number + ".");
                System.out.println(againPrompt);
                answer4 = scanner.nextLine();

            }
        }
        System.out.print(farewellPrompt);
    }

}



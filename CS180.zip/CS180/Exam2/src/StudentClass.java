import java.util.ArrayList;
import java.util.Objects;

public class StudentClass implements ScheduleEntry {
    private String entryName;
    private int credits;
    private boolean prereqs;

    public StudentClass(String entryName, int credits, boolean prereqs) {
        if (entryName == null) {
            throw new NullPointerException();
        }
        if (credits <= 0) {
            throw new IllegalArgumentException();
        }
        this.entryName = entryName;
        this.credits = credits;
        this.prereqs = prereqs;
    }

    @Override
    public String getEntryName() {
        return this.entryName;
    }

    @Override
    public int getCredits() {
        return this.credits;
    }

    @Override
    public boolean hasPrereqs() {
        return this.prereqs;
    }

    @Override
    public double calculateStudentWorkHours(double averageHoursPerCredit, int weeks) {
        double result = weeks * (averageHoursPerCredit * credits);
        if (hasPrereqs()) {
            result = result * 1.4;
        }
        return result;
    }

    @Override
    public String[] findSimilarClasses(ScheduleEntry[] scheduleEntries, int creditThreshold) {
        ArrayList<String> similarClasses = new ArrayList<>();
        for (ScheduleEntry entry : scheduleEntries) {
            if (entry instanceof StudentClass) {
                StudentClass studentClass = (StudentClass) entry;
                int creditsDiff = Math.abs(studentClass.getCredits() - getCredits());
                if (creditsDiff <= creditThreshold) {
                    similarClasses.add(studentClass.getEntryName());
                }
            }
        }
        return similarClasses.toArray(new String[similarClasses.size()]);
    }

}


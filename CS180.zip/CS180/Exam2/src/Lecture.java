public class Lecture extends StudentClass {
    private int enrolledStudentCount;
    private double workHours;

    public Lecture(String entryName, int credits, boolean prereqs, int enrolledStudentCount, double workHours) {
        super(entryName, credits, prereqs);
        if (enrolledStudentCount < 0) {
            throw new IllegalArgumentException();
        }
        if (workHours < 0) {
            throw new IllegalArgumentException();
        }
        this.enrolledStudentCount = enrolledStudentCount;
        this.workHours = workHours;
    }

    public int getEnrolledStudentCount() {
        return enrolledStudentCount;
    }

    public double getWorkHours() {
        return workHours;
    }

    public double calculateTotalWorkHoursScore() {
        return (workHours * enrolledStudentCount);
    }
    public double calculateDifficulty(double averageHoursPerCredit, int weeks){
        return this.workHours - calculateStudentWorkHours(averageHoursPerCredit,weeks);
    }
}

public interface ScheduleEntry {
    public String getEntryName();

    public int getCredits();

    public boolean hasPrereqs();

    public double calculateStudentWorkHours(double averageHoursPerCredit, int weeks);

    public String[] findSimilarClasses(ScheduleEntry[] scheduleEntries, int creditThreshold);

}
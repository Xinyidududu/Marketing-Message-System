import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class CourseProfiler {
    public static final String INPUT_PROMPT = "What is the name of the file you would like to read from?";
    public static final String INPUT_ERROR = "The file doesn't exist!";
    public static final String OUTPUT_PROMPT = "What is the name of the output file?";
    public static final String THRESHOLD_PROMPT = "Enter the ratings threshold filter:";
    public static final String OUTPUT_SUCCESS = "The file was written to!";
    public static final String OUTPUT_ERROR = "There was an error writing to the file.";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(INPUT_PROMPT);
        String inputFile = scanner.nextLine();
        String[] contents = readFile(inputFile);
        if (contents == null) {
            System.out.println(INPUT_ERROR);
            return;
        }
        System.out.println(THRESHOLD_PROMPT);
        String thresholdString = scanner.nextLine();
        double threshold = Double.parseDouble(thresholdString);
        System.out.println(OUTPUT_PROMPT);
        String outFile = scanner.nextLine();
        boolean success = writeFile(contents, threshold, outFile);
        if (success) {
            System.out.println(OUTPUT_SUCCESS);
        } else {
            System.out.println(OUTPUT_ERROR);
        }


    }

    public static String[] readFile(String fileName) {
        String line;
        try {
            BufferedReader bfr = new BufferedReader(new FileReader(fileName));
            ArrayList<String> list = new ArrayList<>();
            while ((line = bfr.readLine()) != null) {
                list.add(line);
            }
            bfr.close();
            String[] array = list.toArray(new String[list.size()]);
            return array;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean writeFile(String[] dataset, double threshold, String fileName) {
        try {
            BufferedWriter bfw = new BufferedWriter(new FileWriter(fileName));
            for (int i = 0; i < dataset.length; i++) {
                String[] courseStringArray = dataset[i].split(",");
                double rating = Double.parseDouble(courseStringArray[courseStringArray.length - 1]);
                if (rating >= threshold) {
                    bfw.write(dataset[i] + "\n");
                }
//                if (i != (dataset.length - 1)) {
//                    bfw.write("\n");
//                }
            }
            bfw.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
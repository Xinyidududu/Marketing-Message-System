import java.io.*;
import java.util.ArrayList;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Spring 2023</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class StockGame extends Thread implements Runnable {
    private static double stockPrice = 100.00;
    private static int availableShares = 100;
    private static int tradeCount = 0;
    private String name;
    private int numShares;
    private String fileName;
    //private static final Object lock = new Object();
    static Object lock = new Object();

    public StockGame(String name, String fileName) {
        this.name = name;
        this.fileName = fileName;
    }

    public void run() {
        //static Object lock = new Object();
        String line1;
        ArrayList<String> allInfo = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            while (true) {
                line1 = reader.readLine();
                if (line1 == null) {
                    break;
                }
                allInfo.add(line1);
            }
            reader.close();
            for (int i = 0; i < allInfo.size(); i++) {
                String writeAll = "";
                String line = allInfo.get(i);
                if (line.split(",")[0].equals("BUY") && Integer.parseInt(line.split(",")[1]) > 0) {
                    this.numShares = Integer.parseInt(line.split(",")[1]);
                    if (availableShares >= numShares) {
                        synchronized (lock) {
                            tradeCount++;
                            writeAll = String.format("----------\nStock Price: %.2f\nAvailable Shares: %d\n" +
                                            "Trade number: %d\nName: %s\nPurchasing %d shares at %.2f..."
                                    , stockPrice, availableShares, tradeCount, name, numShares, stockPrice);
                            System.out.println(writeAll);
                            availableShares = availableShares - numShares;
                            stockPrice = stockPrice + (1.5 * numShares);
                        }
                    } else {
                        synchronized (lock) {
                            writeAll = "----------" + "\n"
                                    + "Insufficient shares available, cancelling order...";
                            System.out.println(writeAll);
                        }
                    }

                } else if (line.split(",")[0].equals("SELL") && Integer.parseInt(line.split(",")[1]) > 0) {
                    this.numShares = Integer.parseInt(line.split(",")[1]);
                    if (availableShares >= numShares) {
                        synchronized (lock) {
                            tradeCount++;
                            writeAll = String.format("----------\nStock Price: %.2f\nAvailable Shares: %d\n" +
                                            "Trade number: %d\nName: %s\nSelling %d shares at %.2f..."
                                    , stockPrice, availableShares, tradeCount, name, numShares, stockPrice);
                            System.out.println(writeAll);
                            availableShares = availableShares + numShares;
                            stockPrice = stockPrice - (2.0 * numShares);
                        }
                    } else {
                        synchronized (lock) {
                            writeAll = "----------" + "\n"
                                    + "Insufficient shares available, cancelling order...";
                            System.out.println(writeAll);
                        }
                    }
                } else {
                    writeAll = "----------" + "\n" + "Error, invalid input!";
                    synchronized (lock) {
                        System.out.println(writeAll);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        try {
            StockGame[] stockTraders = {new StockGame("Xander", "TraderOneMoves"),
                    new StockGame("Afua", "TraderTwoMoves")};

            for (int i = 0; i < stockTraders.length; i++) {
                stockTraders[i].start();
            }
            for (int i = 0; i < stockTraders.length; i++) {
                stockTraders[i].join();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return;
        }

    }

}


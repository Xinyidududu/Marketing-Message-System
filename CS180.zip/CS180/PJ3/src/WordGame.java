import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class WordGame {

    public static String welcome = "Ready to play?";
    public static String yesNo = "1.Yes\n2.No";
    public static String noPlay = "Maybe next time!";
    public static String currentRoundLabel = "Current Round: ";
    public static String enterGuess = "Please enter a guess!";
    public static String winner = "You got the answer!";
    public static String outOfGuesses = "You ran out of guesses!";
    public static String solutionLabel = "Solution: ";
    public static String incorrect = "That's not it!";
    public static String keepPlaying = "Would you like to make another guess?";
    public static String fileNameInput = "Please enter a filename";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> guesses = new ArrayList<>();
        boolean playGame = true;
        boolean playing = true;
        boolean winOrNot = false;
        System.out.println(fileNameInput);
        String fileName = scanner.nextLine();
        WordLibrary wordLibrary = null;
        try {
            wordLibrary = new WordLibrary(fileName);
        } catch (InvalidWordException e) {
            System.out.println("Invalid word!");
        }

        do {
            int currentRound = 1;
            System.out.println(welcome);
            System.out.println(yesNo);
            String playOrNot = scanner.nextLine();
            if (playOrNot.equalsIgnoreCase("2")) {
                System.out.println(noPlay);
                playGame = false;
                break;
            }
            WordGuesser wordGuesser = new WordGuesser(wordLibrary.chooseWord());
            guesses.clear();
            do {
                System.out.println(currentRoundLabel + currentRound);
                wordGuesser.printField();
                System.out.println(enterGuess);
                String userGuess = scanner.nextLine();
                guesses.add(userGuess);
                try {
                    boolean result = wordGuesser.checkGuess(userGuess);
                    if (result) {
                        System.out.println(winner);
                        wordGuesser.printField();
                        winOrNot = true;
                        currentRound = 1;
                        //playing = false;
                        break;
                    } else {
                        if (currentRound != 5) {
                            System.out.println(incorrect);
                            System.out.println(keepPlaying);
                            System.out.println(yesNo);
                            winOrNot = false;
                            //System.out.println(guesses);
                            //System.out.println(playing);
                            String keepPlay = scanner.nextLine();
                            if (keepPlay.equalsIgnoreCase("2")) {
                                wordGuesser.printField();
                                currentRound = 1;
                                playing = false;
                            }
                        }
                        if (currentRound == 5) {
                            System.out.println(outOfGuesses);
                            System.out.println(solutionLabel + wordGuesser.getSolution());
                            wordGuesser.printField();
                            currentRound = 1;
                            playing = false;
                        }
                        currentRound++;
                    }
                } catch (InvalidGuessException e) {
                    e.printStackTrace();
                }
            } while (playing);
            String[] guesses1 = guesses.toArray(new String[guesses.size()]);
            // Print the array elements
            for (int i = 0; i < guesses.size(); i++) {
                guesses1[i] = guesses.get(i);
            }
            //System.out.println(winOrNot);
            updateGameLog(wordGuesser.getSolution(), guesses1, winOrNot);
        } while (playGame);
    }

    public static void updateGameLog(String solution, String[] guesses, boolean solved) {
        //check file exist, if no exist, make new file. If exist append;
        //if file no exist, make new file and initiate new variables
        //if file do exist, read first line, get round number, round_number++
        File file = new File("gamelog.txt");
        int round = 0;
        String blank = "";
        String gameLog;
        String words = "";
        String solvedStatus;

        try {
            BufferedReader bfr = new BufferedReader(new FileReader(file));
            String line = bfr.readLine();
            if (line != null) {
                //get the games completed number
                //convert number to int
                //int++
                //write first line back to file
                line = line.replace("Games Completed: ", "");
                round = Integer.parseInt(line);
            }
            while (true) {
                line = bfr.readLine();
                if (line == null) {
                    break;
                }
                blank = blank + "\n" + line;
            }
            bfr.close();
        } catch (FileNotFoundException e) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        round++;


        for (int i = 0; i < guesses.length; i++) {
            words += guesses[i] + ",";
        }
        if (solved) {
            solvedStatus = "Yes";
        } else {
            solvedStatus = "No";
        }
        gameLog = "Games Completed: " + round + blank + "\n" + "Game "
                + round + "\n" + "- Solution: " + solution + "\n"
                + "- Guesses: " + words.substring(0, words.length() - 1)
                + "\n" + "- Solved: " + solvedStatus;

        try {
            PrintWriter ptw = new PrintWriter(new FileOutputStream(file));
            ptw.println(gameLog);
            ptw.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }


    }
}

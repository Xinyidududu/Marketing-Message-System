import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Objects;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class WordGuesser {
    private String[][] playingField;
    private int round;
    private String solution;

    public WordGuesser(String solution) {
        this.solution = solution;
        this.round = 0;
        this.playingField = new String[5][5];
        for (int row = 0; row < playingField.length; row++) {
            for (int col = 0; col < playingField[row].length; col++) {
                playingField[row][col] = " ";
            }
        }
    }

    public String[][] getPlayingField() {
        return playingField;
    }

    public void setPlayingField(String[][] playingField) {
        this.playingField = playingField;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public boolean checkGuess(String guess) throws InvalidGuessException {
        boolean isCorrect = false;
        if (guess.length() != 5) {
            throw new InvalidGuessException("Invalid Guess!");
        }
        if (Objects.equals(guess, solution)) {
            for (int i = 0; i < 5; i++) {
                String inGuess = guess.substring(i, i + 1);
                String inSolution = solution.substring(i, i + 1);
                if (Objects.equals(inGuess, inSolution)) {
                    inGuess = "'" + inGuess + "'";
                    //System.out.println("add ''" + inGuess);
                    playingField[round][i] = inGuess;
                }
            }
            isCorrect = true;
        } else {
            for (int i = 0; i < 5; i++) {
                String inGuess = guess.substring(i, i + 1);
                String inSolution = solution.substring(i, i + 1);
                if (Objects.equals(inGuess, inSolution)) {
                    inGuess = "'" + inGuess + "'";
                    //System.out.println("add ''" + inGuess);
                    playingField[round][i] = inGuess;
                } else if (!Objects.equals(inGuess, inSolution) && solution.contains(inGuess)) {
                    inGuess = "*" + inGuess + "*";
                    //System.out.println("add **" + inGuess);
                    playingField[round][i] = inGuess;
                } else {
                    inGuess = "{" + inGuess + "}";
                    //System.out.println("add {}" + inGuess);
                    playingField[round][i] = inGuess;
                }
            }
            round++;
            //1. id strings.equals() == true, return true
            //2. write a for loop that goes over each char in guess
            //3. implement "", write if char contained in solution and char's position is correct
            //4. implement **, write if contains
            //5. else, {}
            //6. add result in playingField
        }
        return isCorrect;
    }


    public void printField() {
        //get a row
        //playField[
        for (int row = 0; row < 5; row++) {
            //print all rows
            String result = "";
            for (int col = 0; col < 4; col++) {
                result = result + playingField[row][col] + " | ";
            }
            result = result + playingField[row][4];
            System.out.println(result);
        }
    }
}



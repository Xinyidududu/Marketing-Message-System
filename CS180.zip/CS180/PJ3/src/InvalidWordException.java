/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class InvalidWordException extends Exception {
    public InvalidWordException(String message) {
        super(message);
    }
}

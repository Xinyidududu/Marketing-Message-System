import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class WordLibrary {

    private String fileName;
    private String[] library;
    private int seed;
    private Random random;


    public WordLibrary(String fileName) throws InvalidWordException {
        this.fileName = fileName;
        String line;
        ArrayList<String> newArrayList = new ArrayList<>();
        try {
            BufferedReader bfr = new BufferedReader(new FileReader(fileName));
            //get value of seed from file and call Random;
            line = bfr.readLine();
            line = line.replace("Seed: ", "");
            seed = Integer.parseInt(line);
            while ((line = bfr.readLine()) != null) {
                newArrayList.add(line);
            }
            for (int i = 1; i < newArrayList.size(); i++) {
                library = newArrayList.toArray(new String[i]);
            }
            random = new Random(seed);
            processLibrary();
            bfr.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvalidWordException e) {
            System.out.println("Invalid word!");
        }
    }


    public void verifyWord(String word) throws InvalidWordException {
        if (word.length() != 5) {
            throw new InvalidWordException("Invalid word!");
        }
    }

    public void processLibrary() throws InvalidWordException {
        ArrayList<String> verifiedLibrary = new ArrayList<>();
        for (int i = 0; i < library.length; i++) {
            try {
                verifyWord(library[i]);
                verifiedLibrary.add(library[i]);
                //System.out.println(Arrays.toString(library));
            } catch (InvalidWordException e) {
                verifiedLibrary.remove(library[i]);
                System.out.println("Invalid word!");
                //System.out.println(Arrays.toString(library));
                //throw new InvalidWordException("Invalid word!");
                //System.out.println("Invalid word has been removed!");
            }
        }
        for (int j = 0; j < verifiedLibrary.size(); j++) {
            library = verifiedLibrary.toArray(new String[j]);
        }
    }


    public String chooseWord() {
        return library[random.nextInt(library.length)];
    }

    public String[] getLibrary() {
        return library;
    }

    public void setLibrary(String[] library) {
        this.library = library;
    }

    public int getSeed() {
        return seed;
    }

    public void setSeed(int seed) {
        this.seed = seed;
    }
}

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;

/**
 * Local test cases for CS180 project 4
 *
 * @author Abhi C
 * @version 4/10/23
 */
public class LocalTest {

    public static void main(String[] args) {
        Result result = JUnitCore.runClasses(TestCase.class);
        System.out.printf("Test Count: %d.\n", result.getRunCount());
        if (result.wasSuccessful()) {
            System.out.printf("Excellent - all local tests ran successfully.\n");
        } else {
            System.out.printf("Tests failed: %d.\n", result.getFailureCount());
            for (Failure failure : result.getFailures()) {
                System.out.println(failure.toString());
            }
        }
    }

    /**
     * A set of public test cases.
     *
     * <p>Purdue University -- CS18000 -- Summer 2022</p>
     *
     * @author Purdue CS
     * @version June 13, 2022
     */
    public static class TestCase {
        private final PrintStream originalOutput = System.out;
        private final InputStream originalSysin = System.in;

        @SuppressWarnings("FieldCanBeLocal")
        private ByteArrayInputStream testIn;

        @SuppressWarnings("FieldCanBeLocal")
        private ByteArrayOutputStream testOut;

        @Before
        public void outputStart() {
            testOut = new ByteArrayOutputStream();
            System.setOut(new PrintStream(testOut));
        }

        @After
        public void restoreInputAndOutput() {
            System.setIn(originalSysin);
            System.setOut(originalOutput);
        }

        private String getOutput() {
            return testOut.toString();
        }

        @SuppressWarnings("SameParameterValue")
        private void receiveInput(String str) {
            testIn = new ByteArrayInputStream(str.getBytes());
            System.setIn(testIn);
        }

        // Each of the correct outputs
        public static final String MENUMAIN = "Tapdancing Shoes Marketplace Messenger Menu:\n" +
                "1. Send message to a customer" +
                "\n2. View message history\n3. View my stores dashboards\n4. Manage stores" +
                "\n5. Choose users to block\n6. Choose users to become invisible to\n7. Edit account" +
                "\n8. Delete Account\n9. Log out";
        public static final String WELCOME_MESSAGE = "Welcome to Marketplace Messenger!";
        public static final String MENU = "Sign Up/Login Menu \n1. Returning seller? Log in\n2. Returning customer?" +
                " Log in\n3. New user? Sign up\n4. Quit";
        public static final String LOGIN = "Please enter your email.\nPlease enter your password.";
        public static final String FAILURE = "Your login information is invalid!\n" +
                "Do you want to try to log in again?\n" +
                "1. Yes\n2. No";
        public static final String WELCOME_SNIG = "Welcome, snig!";
        public static final String USER_SELECT = "Select a user to message!";
        public static final String MESSAGE_SENT = "Message Sent!";
        public static final String USERS = "1. Mary\n2. Karen";
        public static final String MESSAGE_PROMPT = "What is your message?";
        public static final String GOODBYE_MESSAGE = "See you next time!";

        @Test(timeout = 1000)
        public void testExpectedOne() throws Exception {
            System.out.println("testing");
            // Set the input
            String input = "1" + System.lineSeparator()
                    + "s@gm" + System.lineSeparator()
                    + "sniggy" + System.lineSeparator()
                    + "1" + System.lineSeparator()
                    + "s@g" + System.lineSeparator()
                    + "sniggy" + System.lineSeparator()
                    + "1" + System.lineSeparator()
                    + "1" + System.lineSeparator()
                    + "Test Message"  + System.lineSeparator()
                    + "9"  + System.lineSeparator()
                    + "4" + System.lineSeparator();

            // Pair the input with the expected result
            String expected = WELCOME_MESSAGE + System.lineSeparator()
                    + MENU + System.lineSeparator()
                    + LOGIN + System.lineSeparator()
                    + FAILURE + System.lineSeparator()
                    + LOGIN + System.lineSeparator()
                    + WELCOME_SNIG + System.lineSeparator()
                    + MENUMAIN + System.lineSeparator()
                    + USER_SELECT + System.lineSeparator()
                    + USERS + System.lineSeparator()
                    + MESSAGE_PROMPT + System.lineSeparator()
                    + MESSAGE_SENT + System.lineSeparator()
                    + MENUMAIN + System.lineSeparator()
                    + MENU + System.lineSeparator()
                    + GOODBYE_MESSAGE + System.lineSeparator();

            // Runs the program with the input values
            receiveInput(input);
            Main.main(new String[0]);

            // Retrieves the output from the program
            String output = getOutput();

            // Trims the output and verifies it is correct.
            expected = expected.replaceAll("\r\n", "\n");
            output = output.replaceAll("\r\n", "\n");
            assertEquals("Make sure you follow the flowchart and use the given strings for the result!",
                    expected.trim(), output.trim());
        }
    }
}

import java.util.ArrayList;
import java.util.Scanner;
/**
 * The interactive Main Class for CS180 project 4
 *
 * @author Abhi Chalasani, Xinyi Guan, Marissa Capelli, Snigdha Mishra
 * @version 4/10/23
 */

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String username = "";
        String email = "";
        String password = "";
        boolean continueProgram = true;
        Customer customer = new Customer();
        Seller seller = new Seller();
        Seller tempSeller = new Seller();

        // PHASE 1: LOGIN/SIGN UP
        System.out.println("Welcome to Tapdancing Shoes Marketplace Messenger!");
        int returningOrNew = -1;
        while (continueProgram) {
            // CONTAINS ENTIRE PROGRAM: LOOPS UNTIL EXIT
            while (true) {
                // Main menu for sign up/login
                System.out.println("Sign Up/Login Menu");
                System.out.printf("1. Returning seller? Log in\n2. Returning customer? Log in" +
                        "\n3. New user? Sign up\n4. Quit\n");
                returningOrNew = customer.getAndVerifyValidNumber(1, 4);
                if (returningOrNew != -1) {
                    break;
                }
            }
            // LOGIN: requires an email and password (each email is unique)
            if (returningOrNew == 1 || returningOrNew == 2) {
                boolean validLogin = false;
                int tryAgain = -1;
                while (!validLogin && (tryAgain != 2)) {
                    // Loops while the user has neither given a valid login nor indicated a desire
                    // to go back
                    System.out.println("Please enter your email.");
                    email = scan.nextLine();
                    System.out.println("Please enter your password.");
                    password = scan.nextLine();
                    if (returningOrNew == 1) {
                        // returns a seller object or null customer object
                        seller = tempSeller.verifySellerLogin(email, password);
                        if (seller != null && !seller.getEmail().equals("")) {
                            // the login is valid if the seller object was assigned a valid email
                            validLogin = true;
                        }
                    } else if (returningOrNew == 2) {
                        // should return a customer object or null customer object
                        customer = customer.verifyCustomerLogin(email, password);
                        //System.out.println(customer);
                        if (customer != null && !customer.getEmail().equals("")) {
                            // the login is valid if the customer object was assigned a valid ID
                            validLogin = true;
                        }
                    }
                    if (!validLogin) {
                        System.out.println("Your login information is invalid!");
                        while (true) {
                            System.out.println("Do you want to try to log in again?");
                            System.out.println("1. Yes\n2. No");
                            // This method takes in input and evaluates it. If valid, it returns the given
                            // int.
                            // If invalid, it prints and error message and returns -1
                            tryAgain = customer.getAndVerifyValidNumber(1, 2);
                            if (tryAgain != -1) {
                                break;
                            }
                        }
                    }
                }
                // CREATE NEW ACCOUNT
            } else if (returningOrNew == 3) {
                int newAccountType = -1;
                System.out.println("Would you like to make a customer or seller account?");
                while (true) {
                    try {
                        System.out.printf("1. Create Customer Account\n2. Create Seller Account\n");
                        newAccountType = Integer.parseInt(scan.nextLine());
                        if (newAccountType > 2 || newAccountType < 1) {
                            throw new NumberFormatException();
                        } else {
                            break;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number!");
                    }
                }
                looper:
                while (true) {
                    System.out.println("What email should be associated with your account?");
                    email = scan.nextLine();
                    if (email.isEmpty()) {
                        System.out.println("ERROR: No email entered!");
                        continue;
                    }
                    if (!seller.verifyUniqueEmail(email)) {
                        System.out.println("ERROR: An account already exists with that email!");
                        continue;
                    }
                    break;
                }
                usernameLoop:
                while (true) {
                    System.out.println("Please choose your username.");
                    username = scan.nextLine();
                    if (username.isEmpty()) {
                        System.out.println("ERROR: No username entered!");
                        continue;
                    }
                    if (!seller.verifyUniqueUsername(username)) {
                        System.out.println("ERROR: An account already exists with that username!");
                        continue;
                    }
                    break;
                }

                while (true) {
                    System.out.println("Please choose your password.");
                    password = scan.nextLine();
                    if (!password.isEmpty())
                        break;
                    System.out.println("ERROR: No password entered!");
                }
                if (newAccountType == 1) {
                    // Create new customer with information gathered
                    customer.setEmail(email);
                    customer.setUsername(username);
                    customer.setPassword(password);
                    customer.setID(customer.generateNewID());
                    customer.createCustomerAccount(username, email, password);
                    System.out.println("Customer account created!");

                } else if (newAccountType == 2) {
                    // Create new seller with information gathered
                    seller = new Seller(username, email, password);
                    System.out.println("Seller account created!");
                }
            } else if (returningOrNew == 4) {
                System.out.println("See you next time!");
                return;

            }

            // PHASE 2: USING ACCOUNT
            boolean loggedIn = true;

            // PHASE 2C: CUSTOMER EXPERIENCE
            String messengerCustomerMainMenu = "Tapdancing Shoes Marketplace Messenger Menu: \n" +
                    "1. Send message to a seller" +
                    "\n2. Send message to a store\n3. View message history\n4. View all store dashboards " +
                    "\n5. Choose users to block\n6. Choose users to become invisible to\n7. Edit account " +
                    "\n8. Delete account\n9. Log out";
            if (customer.getID() > 0) {
                System.out.printf("Welcome, %s!\n", customer.getUsername());
                while (loggedIn) {
                    int mainMenuChoice = -1;
                    while (mainMenuChoice == -1) {
                        System.out.println(messengerCustomerMainMenu);
                        mainMenuChoice = customer.getAndVerifyValidNumber(1, 9);
                    }
                    if (mainMenuChoice == 1) {
                        // 1. Send message to a seller
                        ArrayList<String> sellerArrayList = customer.getSellerList();
                        ArrayList<Integer> sellerIDArrayList = new ArrayList<Integer>();
                        System.out.println("Enter the ID of the user you wish to message!");
                        for (int i = 0; i < sellerArrayList.size(); i++) {
                            System.out.println(sellerArrayList.get(i));
                            String[] splitString = sellerArrayList.get(i).split(":");
                            sellerIDArrayList.add(Integer.parseInt(splitString[1]));
                        }
                        String choiceOfSeller = scan.nextLine();
                        int choiceOfSellerID = -1;
                        try {
                            choiceOfSellerID = Integer.parseInt(choiceOfSeller);
                            if (sellerIDArrayList.indexOf(choiceOfSellerID) == -1) {
                                throw new NumberFormatException();
                            }
                            System.out.println("What is your message?");
                            String messageToSeller = scan.nextLine();
                            customer.sendMessageToSeller(choiceOfSellerID, messageToSeller);
                            System.out.println("Message Sent!");
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input!");
                        }

                    } else if (mainMenuChoice == 2) {
                        // 2. Send message to a store
                        ArrayList<String> storeArrayList = customer.getStoreList();
                        System.out.println("Which store would you like to message?");
                        for (int i = 0; i < storeArrayList.size(); i++) {
                            System.out.printf("%d. %s\n", (i + 1), storeArrayList.get(i));
                        }
                        int choiceOfStoreIndex = -1;
                        int sellerID = -1;
                        int storeID = -1;
                        String selectedStore = "";
                        try {
                            choiceOfStoreIndex = Integer.parseInt(scan.nextLine());
                            if (!(choiceOfStoreIndex > 0 && choiceOfStoreIndex <= storeArrayList.size())) {
                                throw new NumberFormatException();
                            }
                            choiceOfStoreIndex -= 1;
                            // Format of string -> Store: %s (ID:%d.%d)
                            selectedStore = storeArrayList.get(choiceOfStoreIndex);
                            String selectedStoreName = selectedStore.substring(selectedStore.indexOf(":") + 2,
                                    selectedStore.indexOf("(") - 1);
                            String sellerIDString = selectedStore.substring(selectedStore.indexOf(".") + 1,
                                    selectedStore.indexOf(".", selectedStore.indexOf(".") + 1));
                            sellerID = Integer.parseInt(sellerIDString);
                            storeID = Integer.parseInt(selectedStore.substring(selectedStore.indexOf("."
                                    , selectedStore.indexOf(".") + 1)
                                    + 1, selectedStore.indexOf(")")));

                            System.out.println("What is your message?");
                            String messageToStore = scan.nextLine();

                            customer.sendMessageToStore(sellerID, storeID, messageToStore);

                            System.out.println("Message Sent!");

                        } catch (NumberFormatException e) {
                            System.out.println("Invalid Input!");
                        }


                    } else if (mainMenuChoice == 3) {
                        // 3. View message history

                        try {
                            int userChoice = -1;
                            String repeatString = "";
                            do {
                                int sellerID = -1;
                                int sellerChoice = -1;
                                String sellerName = "";
                                ArrayList<String> sellerLineList = customer.getSellerList();
                                // Returns list of --> Sniggy, ID:3
                                // ArrayList<String> cusNameList = seller.getUsernamesFromCustomerArrayList(cusList);
                                if (sellerLineList.size() != 0) {
                                    System.out.println("Choose a seller to view history");
                                    for (int i = 0; i < sellerLineList.size(); i++) {
                                        System.out.println("" + (i + 1) + ". " + sellerLineList.get(i));
                                    }
                                    while (true) {
                                        userChoice = Integer.parseInt(scan.nextLine());
                                        if (userChoice > 0 || (userChoice <= sellerLineList.size())) {
                                            break;
                                        }
                                        System.out.println("Choose a valid number!");
                                    }
                                    String chosenSellerPrintString = sellerLineList.get(userChoice - 1);
                                    String[] splitChosenSellerPrintString = chosenSellerPrintString.split(":");
                                    sellerID = Integer.parseInt(splitChosenSellerPrintString[1]);
                                    ArrayList<String> messagesHistory
                                            = customer.getSpecificMessageHistory(customer.getID());
                                    if (messagesHistory.isEmpty()) {
                                        System.out.println("No history exists!");
                                        System.out.println("Returning to main menu");
                                        break;
                                    } else {
                                        int index = 0;
                                        for (String s : sellerLineList)
                                            if (s.contains("ID:" + sellerID))
                                                sellerName = s.substring(0, s.indexOf(","));
                                        for (String s : messagesHistory) {
                                            index++;
                                            System.out.printf("%d. %s\n", index, seller.formatMessage(s, sellerName));
                                        }
                                    }
                                    System.out.println("Options:\n1. Edit Message" +
                                            "\n2. Delete Message\n3. Return to menu");
                                    try {
                                        userChoice = Integer.parseInt(scan.nextLine());
                                        if (userChoice < 1 || userChoice > 3) {
                                            throw new NumberFormatException();
                                        }
                                    } catch (NumberFormatException e) {
                                        System.out.println("Invalid input!");
                                        break;
                                    }
                                    if (userChoice == 1) {
                                        // Option 1. Edit Message
                                        int messageIndex = 0;
                                        ArrayList<String> formattedMessageHistory = new ArrayList<>();
                                        System.out.println("Select a message to edit:");
                                        String formattedMessage = "";
                                        int counter = 1;
                                        for (int i = 0; i < messagesHistory.size(); i++) {
                                            formattedMessage = seller.formatMessageForEdit(messagesHistory.get(i));
                                            if (!formattedMessage.isEmpty()) {
                                                formattedMessageHistory.add((counter) + ". " + formattedMessage);
                                                System.out.println(formattedMessageHistory.get(counter - 1));
                                                counter++;
                                            }
                                        }
                                        try {
                                            messageIndex = Integer.parseInt(scan.nextLine());
                                            if (messageIndex > formattedMessageHistory.size() || messageIndex < 1)
                                                throw new NumberFormatException();
                                            int messageToBeEditedIndex
                                                    = formattedMessageHistory.get(messageIndex - 1).indexOf(": ");
                                            messageToBeEditedIndex += 2;
                                            String formattedM = formattedMessageHistory.get(messageIndex - 1);
                                            String messageToBeEdited
                                                    = formattedM.substring(messageToBeEditedIndex);
                                            System.out.println("What would you like the edited message to be?");
                                            String editedMessageInput;
                                            do {
                                                editedMessageInput = scan.nextLine();
                                                if (editedMessageInput.isEmpty())
                                                    System.out.println("Please enter a new message!");
                                            } while (editedMessageInput.isEmpty());
                                            seller.editMessage(messageToBeEdited, editedMessageInput);
                                            System.out.println("Message Edited!");
                                        } catch (NumberFormatException e) {
                                            System.out.println("Invalid Input!");
                                            System.out.println("Returning to main menu");
                                        }

                                    } else if (userChoice == 2) {
                                        // Option 2. Delete Message
                                        int messageIndex = 0;
                                        ArrayList<String> formattedMessageHistory = new ArrayList<>();
                                        System.out.println("Select a message to Delete:");
                                        String formattedMessage = "";
                                        int counter = 1;
                                        for (int i = 0; i < messagesHistory.size(); i++) {
                                            formattedMessage = seller.formatMessageForEdit(messagesHistory.get(i));
                                            if (!formattedMessage.isEmpty()) {
                                                formattedMessageHistory.add((counter) + ". " + formattedMessage);
                                                System.out.println(formattedMessageHistory.get(counter - 1));
                                                counter++;
                                            }
                                        }
                                        try {
                                            messageIndex = Integer.parseInt(scan.nextLine());
                                            if (messageIndex > formattedMessageHistory.size() || messageIndex < 1)
                                                throw new NumberFormatException();
                                            String formattedM = formattedMessageHistory.get(messageIndex - 1);
                                            int messageToBeDeletedIndex = formattedM.indexOf(": ");
                                            messageToBeDeletedIndex += 2;
                                            String messageToBeDeleted = formattedM.substring(messageToBeDeletedIndex);
                                            System.out.println("Deleting message [" + messageToBeDeleted + "]");
                                            System.out.println("Note: This only deletes a message for you" +
                                                    ", the receiver may still be able to view it");
                                            System.out.println("Are you sure you want to delete this message?");
                                            System.out.println("1.Yes\n2.No");
                                            int deleteConfirmation = Integer.parseInt(scan.nextLine());
                                            if (deleteConfirmation == 1) {
                                                seller.deleteMessage(messageToBeDeleted);
                                                System.out.println("Message deleted!");
                                            } else {
                                                System.out.println("Message Deletion canceled!");
                                                System.out.println("Back to the main menu!");
                                            }

                                        } catch (NumberFormatException e) {
                                            System.out.println("Invalid input!");
                                            System.out.println("Returning to main menu");
                                        }
                                    } else {
                                        System.out.println("Back to the main menu!");
                                    }


                                } else {
                                    System.out.println("There are no messages for you to view!");
                                    break;
                                }
                                System.out.println("Would you like to view other conversations? (Type yes or no)");
                                repeatString = scan.nextLine();
                            } while (repeatString.equalsIgnoreCase("Yes"));
                        } catch (NumberFormatException e) {
                            System.out.println("Not a Valid Number!");
                            System.out.println("Returning to main menu");
                        }

                    } else if (mainMenuChoice == 4) {

                        // 4. View all store dashboards
                        String dashB = customer.displayDashboard(customer.getID());
                        System.out.println(dashB);
                        System.out.println("Do you want to sort the dashboard?\nYes\nNo");
                        String response = scan.nextLine();
                        if (response.equalsIgnoreCase("Yes")) {
                            String sortedB = customer.sortDashboard();
                            System.out.print(sortedB);
                        }

                    } else if (mainMenuChoice == 5) {
                        // 5. Choose users to block
                        /*boolean blockAgain;
                        ArrayList<Integer> blockSellerID = new ArrayList<>();
                        do {
                            String beforeBlockSellerList = String.valueOf(customer.getSellerList());
                            beforeBlockSellerList = beforeBlockSellerList.substring(1,
                                    beforeBlockSellerList.length() - 1);
                            if (beforeBlockSellerList.equals("ul")){
                                System.out.println("There are no sellers available.");
                                break;
                            }
                            System.out.println(beforeBlockSellerList);
                            System.out.println("Please enter the ID of the seller that you want to block: ");
                            int blockSellerIDs = Integer.parseInt(scan.nextLine());
                            blockSellerID.add(blockSellerIDs);
                            customer.setBlockedPeople(blockSellerID);
                            System.out.println("Finished blocking!");
                            System.out.println("Do you want to block more people?\nYes\nNo");
                            String blockMore = scan.nextLine();
                            if (blockMore.equalsIgnoreCase("No")) {
                                blockAgain = false;
                            } else if (blockMore.equalsIgnoreCase("Yes")) {
                                blockAgain = true;
                            } else {
                                System.out.println("Invalid input! Back to the main manu!");
                                blockAgain = false;
                            }
                        } while (blockAgain);*/

                        int blocker = -1;
                        do {
                            System.out.println("Would you like to add or remove blocked users?");
                            System.out.println("1. Add\n2. Remove");
                            try {
                                blocker = Integer.parseInt(scan.nextLine());
                            } catch (NumberFormatException e) {
                                // Do nothing, if it doesn't work the value is already set to -1
                            }
                            if (blocker == 1) {
                                // Adding customers to wasBlockedBy in customerData and hasBlocked in sellerData
                                String beforeBlockSellerList = String.valueOf(customer.getSellerList());
                                beforeBlockSellerList = beforeBlockSellerList.substring(1,
                                        beforeBlockSellerList.length() - 1);
                                if (beforeBlockSellerList.equals("ul")) {
                                    System.out.println("There are no sellers available.");
                                    break;
                                }
                                System.out.println(beforeBlockSellerList);
                                System.out.println("Please enter the ID of the seller that you want to block: ");
                                int blockSellerIDs;
                                try {
                                    blockSellerIDs = Integer.parseInt(scan.nextLine());
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid input");
                                    break;
                                }
                                customer.addBlockedUser(blockSellerIDs);
                                System.out.println("Finished blocking!");
                            } else if (blocker == 2) {
                                // Removing customers from wasBlockedBy in customerData and hasBlocked in sellerData
                                System.out.println("Please enter the ID of the Seller that you want to unblock:");
                                ArrayList<String> blockedSellerNameList = customer.getBlockedSellerNameList();
                                if (!blockedSellerNameList.isEmpty()) {
                                    for (int i = 0; i < blockedSellerNameList.size(); i++) {
                                        System.out.println(blockedSellerNameList.get(i));
                                    }
                                } else {
                                    System.out.println("You have no blocked Sellers!");
                                    break;
                                }
                                int sellerToBeBlockedID = Integer.parseInt(scan.nextLine());
                                customer.removeBlockedUser(sellerToBeBlockedID);
                                System.out.println("Finished unblocking!");
                            } else {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }

                            System.out.println("Do you want to block/unblock more people? (Type yes or no)");
                            String blockMore = scan.nextLine();
                            if (blockMore.equalsIgnoreCase("No")) {
                                break;
                            } else if (!blockMore.equalsIgnoreCase("Yes")) {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }
                        } while (true);
                    } else if (mainMenuChoice == 6) {
                        ArrayList<Integer> invisibleToID = new ArrayList<>();
                        boolean changeAgain;
                        // 6. Choose users see as invisible
                        do {
                            String beforeInvisibleSellerList = String.valueOf(customer.getSellerList());
                            beforeInvisibleSellerList = beforeInvisibleSellerList.substring(1,
                                    beforeInvisibleSellerList.length() - 1);
                            //ArrayList<Integer> invisibleToID = new ArrayList<>();
                            if (beforeInvisibleSellerList.equals("ul")) {
                                System.out.println("There are no sellers available.");
                                break;
                            }
                            System.out.println(beforeInvisibleSellerList);
                            System.out.println("Please enter the ID of user that you want to become invisible to: ");
                            int invisibleToIDs = Integer.parseInt(scan.nextLine());
                            invisibleToID.add(invisibleToIDs);
                            customer.setSeesAsInvisible(invisibleToID);
                            System.out.println("Finished change!");
                            System.out.println("Do you want to become invisible to more people?\nYes\nNo");
                            String changeMore = scan.nextLine();
                            if (changeMore.equalsIgnoreCase("No")) {
                                changeAgain = false;
                            } else if (changeMore.equalsIgnoreCase("Yes")) {
                                changeAgain = true;
                            } else {
                                System.out.println("Invalid input! Back to the main manu!");
                                changeAgain = false;
                            }
                        } while (changeAgain);
                    } else if (mainMenuChoice == 7) {
                        // 7. Edit account - Finished
                        String response;
                        do {
                            System.out.println("Are you going to edit the account?");
                            response = scan.nextLine();
                            if (response.equalsIgnoreCase("Yes")) {
                                System.out.println("Are you going to edit through username or password?");
                                String responseTwo = scan.nextLine();
                                if (responseTwo.equalsIgnoreCase("Username")) {
                                    System.out.println("What username you want to change into?");
                                    String newUsername = scan.nextLine();
                                    customer.editUserName(customer.getUsername(), newUsername);
                                    System.out.println("Successful username change made.");
                                } else if (responseTwo.equalsIgnoreCase("Password")) {
                                    System.out.println("What password you want to change into?");
                                    String newPassword = scan.nextLine();
                                    customer.editPassword(password, newPassword);
                                    System.out.println("Successful password change made.");
                                }
                            } else if (response.equalsIgnoreCase("No")) {
                                break;
                            }
                        } while (!(response.equalsIgnoreCase("Yes")) && !(response.equalsIgnoreCase("No")));

                    } else if (mainMenuChoice == 8) {
                        // 8. Delete account - Finished
                        String response2;
                        do {
                            System.out.println("Are you going to delete the account?");
                            response2 = scan.nextLine();
                            if (response2.equalsIgnoreCase("Yes")) {
                                System.out.println("What is your email?");
                                String responseTwo = scan.nextLine();
                                customer.deleteAccount(responseTwo);
                            } else if (response2.equalsIgnoreCase("No")) {
                                break;
                            }
                        } while (!(response2.equalsIgnoreCase("Yes")) && !(response2.equalsIgnoreCase("No")));
                    } else if (mainMenuChoice == 9) {
                        // 9. Log out
                        loggedIn = false;
                    }
                }
            }

            // PHASE 2S: SELLER EXPERIENCE

            String messengerSellerMainMenu = "Tapdancing Shoes Marketplace Messenger Menu:" +
                    "\n1. Send message to a customer" +
                    "\n2. View message history\n3. View my stores dashboards\n4. Manage stores" +
                    "\n5. Choose users to block\n6. Choose users to become invisible to\n7. Edit account" +
                    "\n8. Delete Account\n9. Log out";

            if (seller.getID() > 0) {
                System.out.printf("Welcome, %s!\n", seller.getUsername());
                while (loggedIn) {
                    int mainMenuChoice = -1;
                    while (mainMenuChoice == -1) {
                        System.out.println(messengerSellerMainMenu);
                        mainMenuChoice = seller.getAndVerifyValidNumber(1, 9);
                    }
                    if (mainMenuChoice == 1) {
                        ArrayList<String> customerArrayList = seller.getCustomerNameList();
                        ArrayList<String> customerNamesList
                                = seller.getUsernamesFromCustomerArrayList(customerArrayList);
                        if (customerNamesList.size() != 0) {
                            System.out.println("Select a user to message!");

                            for (int i = 0; i < customerNamesList.size(); i++) {
                                System.out.println("" + (i + 1) + ". " + customerNamesList.get(i));
                            }
                            int choiceOfCustomerIndex = -1;
                            int customerWhoReceivesMessageID = -1;
                            while (true) {
                                choiceOfCustomerIndex = seller.getAndVerifyValidNumber(1,
                                        (customerArrayList.size() + 1));
                                if (choiceOfCustomerIndex > 0) {
                                    break;
                                }
                            }
                            choiceOfCustomerIndex -= 1;
                            try {
                                customerWhoReceivesMessageID = seller
                                        .getCustomerIDFromPrintString(customerArrayList.get(choiceOfCustomerIndex));
                                //problem in step 1
                            } catch (Exception e) {
                                System.out.println("Cannot find this ID.");
                            }
                            System.out.println("What is your message?");
                            String messageToCustomer = scan.nextLine();
                            seller.sendMessageToCustomer(customerWhoReceivesMessageID, messageToCustomer);
                            System.out.println("Message Sent!");
                        } else {
                            System.out.println("There are no users for you to message!");
                        }
                    } else if (mainMenuChoice == 2) {
                        // 2. View message history
                        try {
                            int userChoice = -1;
                            String repeatString = "";
                            do {
                                int cusID = -1;
                                int cusChoice = -1;
                                String cusName = "";
                                ArrayList<String> cusList = seller.getCustomerNameList();
                                ArrayList<String> cusNameList = seller.getUsernamesFromCustomerArrayList(cusList);
                                if (cusNameList.size() != 0) {
                                    System.out.println("Choose a Customer to view history");
                                    for (int i = 0; i < cusNameList.size(); i++) {
                                        System.out.println("" + (i + 1) + ". " + cusNameList.get(i));
                                    }
                                    while (true) {
                                        cusChoice = seller.getAndVerifyValidNumber(1,
                                                (cusList.size() + 1));
                                        if (cusChoice > 0) {
                                            break;
                                        }
                                        System.out.println("Select a valid number!");
                                    }
                                    cusID = seller.getCustomerIDFromPrintString(cusList.get(cusChoice - 1));
                                    ArrayList<String> messagesHistory = seller.getSpecificMessageHistory(cusID);
                                    if (messagesHistory.isEmpty()) {
                                        System.out.println("No history exists!");
                                        System.out.println("Returning to main menu");
                                        break;
                                    } else {
                                        for (String s : cusList)
                                            if (s.contains("ID - " + cusID))
                                                cusName = s.substring(0, s.indexOf(","));
                                        for (String s : messagesHistory) {
                                            System.out.println(seller.formatMessage(s, cusName));
                                        }
                                    }
                                    System.out.println("Options:\n1. Edit Message\n" +
                                            "2. Delete Message\n3. Return to menu");
                                    try {
                                        userChoice = Integer.parseInt(scan.nextLine());
                                        if (userChoice < 1 || userChoice > 3) {
                                            throw new NumberFormatException();
                                        }
                                    } catch (NumberFormatException e) {
                                        System.out.println("Invalid input!");
                                        break;
                                    }
                                    if (userChoice == 1) {
                                        // Option 1. Edit Message
                                        int messageIndex = 0;
                                        ArrayList<String> formattedMessageHistory = new ArrayList<>();
                                        System.out.println("Select a message to edit:");
                                        String formattedMessage = "";
                                        int counter = 1;
                                        for (int i = 0; i < messagesHistory.size(); i++) {
                                            formattedMessage = seller.formatMessageForEdit(messagesHistory.get(i));
                                            if (!formattedMessage.isEmpty()) {
                                                formattedMessageHistory.add((counter) + ". " + formattedMessage);
                                                System.out.println(formattedMessageHistory.get(counter - 1));
                                                counter++;
                                            }
                                        }
                                        try {
                                            messageIndex = Integer.parseInt(scan.nextLine());
                                            if (messageIndex > formattedMessageHistory.size() || messageIndex < 1)
                                                throw new NumberFormatException();
                                            String formattedM = formattedMessageHistory.get(messageIndex - 1);
                                            int messageToBeEditedIndex = formattedM.indexOf(": ");
                                            messageToBeEditedIndex += 2;
                                            String messageToBeEdited = formattedM.substring(messageToBeEditedIndex);
                                            System.out.println("What would you like the edited message to be?");
                                            String editedMessageInput;
                                            do {
                                                editedMessageInput = scan.nextLine();
                                                if (editedMessageInput.isEmpty())
                                                    System.out.println("Please enter a new message!");
                                            } while (editedMessageInput.isEmpty());
                                            seller.editMessage(messageToBeEdited, editedMessageInput);
                                            System.out.println("Message Edited!");
                                        } catch (NumberFormatException e) {
                                            System.out.println("Invalid Input!");
                                            System.out.println("Returning to main menu");
                                        }

                                    } else if (userChoice == 2) {
                                        // Option 2. Delete Message
                                        int messageIndex = 0;
                                        ArrayList<String> formattedMessageHistory = new ArrayList<>();
                                        System.out.println("Select a message to Delete:");
                                        String formattedMessage = "";
                                        int counter = 1;
                                        for (int i = 0; i < messagesHistory.size(); i++) {
                                            formattedMessage = seller.formatMessage(messagesHistory.get(i), cusName);
                                            if (!formattedMessage.isEmpty()) {
                                                formattedMessageHistory.add((counter) + ". " + formattedMessage);
                                                System.out.println(formattedMessageHistory.get(counter - 1));
                                                counter++;
                                            }
                                        }
                                        try {
                                            messageIndex = Integer.parseInt(scan.nextLine());
                                            if (messageIndex > formattedMessageHistory.size() || messageIndex < 1)
                                                throw new NumberFormatException();
                                            String formattedM = formattedMessageHistory.get(messageIndex - 1);
                                            int messageToBeDeletedIndex = formattedM.indexOf(": ");
                                            messageToBeDeletedIndex += 2;
                                            String messageToBeDeleted = formattedM.substring(messageToBeDeletedIndex);
                                            System.out.println("Deleting message [" + messageToBeDeleted + "]");
                                            System.out.println("Note: This only deletes a message for you" +
                                                    ", the user may still be able to view it");
                                            System.out.println("Are you sure you want to delete this message?");
                                            System.out.println("1.Yes\n2.No");
                                            int deleteConfirmation = Integer.parseInt(scan.nextLine());
                                            if (deleteConfirmation == 1) {
                                                seller.deleteMessage(messageToBeDeleted);
                                                System.out.println("Message deleted!");
                                            } else {
                                                System.out.println("Message Deletion canceled!");
                                                System.out.println("Back to the main menu!");
                                            }

                                        } catch (NumberFormatException e) {
                                            System.out.println("Invalid input!");
                                            System.out.println("Returning to main menu");
                                        }
                                    } else {
                                        System.out.println("Back to the main menu!");
                                    }


                                } else {
                                    System.out.println("There are no messages for you to view!");
                                    break;
                                }
                                System.out.println("Would you like to view other conversations? (Type yes or no)");
                                repeatString = scan.nextLine();
                            } while (repeatString.equalsIgnoreCase("Yes"));
                        } catch (NumberFormatException e) {
                            System.out.println("Not a Valid Number!");
                            System.out.println("Returning to main menu");
                        }

                    } else if (mainMenuChoice == 3) {
                        // 3. View my stores dashboards
                        System.out.println("You choose 3. View my stores dashboards");
                        String responser = "";
                        int storeID = -1;
                        int choice = -1;
                        String choice1 = "";
                        try {
                            do {
                                String formattedStoreString = seller.formatStores();
                                if (formattedStoreString != null || !formattedStoreString.isEmpty()) {
                                    System.out.println("Type in a Store ID to view");
                                    System.out.print(formattedStoreString);
                                    storeID = Integer.parseInt(scan.nextLine());
                                    ArrayList<String> dashboardWords;
                                    ArrayList<String> dashboardUsers;
                                    System.out.println("Would you like the user dashboard or word dashboard?");
                                    System.out.println("1. User\n2. Word");
                                    choice = Integer.parseInt(scan.nextLine());
                                    if (choice == 1) {
                                        dashboardUsers = seller.getDashboardUserList(storeID);
                                        if (dashboardUsers.isEmpty()) {
                                            System.out.println("No such store exists!");
                                            System.out.println("Returning to main menu");
                                        } else {
                                            if (dashboardUsers.size() > 10) {
                                                for (int i = 0; i < 10; i++) {
                                                    System.out.println(dashboardUsers.get(i));
                                                }
                                            } else {
                                                for (String s : dashboardUsers) {
                                                    System.out.println(s);
                                                }
                                            }
                                            System.out.println("Would you like to view it from least to most?" +
                                                    " (Type yes or no)");
                                            choice1 = scan.nextLine();
                                            if (choice1.equalsIgnoreCase("yes")) {
                                                if (dashboardUsers.size() > 10) {
                                                    for (int i = 9; i >= 0; i--) {
                                                        System.out.println(dashboardUsers.get(i));
                                                    }
                                                } else {
                                                    for (int i = dashboardUsers.size() - 1; i >= 0; i--) {
                                                        System.out.println(dashboardUsers.get(i));
                                                    }
                                                }
                                            }
                                        }
                                    } else if (choice == 2) {
                                        dashboardWords = seller.getDashboardList(storeID);
                                        if (dashboardWords.isEmpty()) {
                                            System.out.println("No such store exists!");
                                            System.out.println("Returning to main menu");
                                        } else {
                                            if (dashboardWords.size() > 10)
                                                for (int i = 0; i < 10; i++) {
                                                    System.out.println(dashboardWords.get(i));
                                                }
                                            else
                                                for (String s : dashboardWords) {
                                                    System.out.println(s);
                                                }
                                            System.out.println("Would you like to view it from least to most?" +
                                                    " (Type yes or no)");
                                            choice1 = scan.nextLine();
                                            if (choice1.equalsIgnoreCase("yes")) {
                                                if (dashboardWords.size() > 10) {
                                                    for (int i = 9; i >= 0; i--) {
                                                        System.out.println(dashboardWords.get(i));
                                                    }
                                                } else {
                                                    for (int i = dashboardWords.size() - 1; i >= 0; i--) {
                                                        System.out.println(dashboardWords.get(i));
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        System.out.println("Invalid number!");
                                        System.out.println("Returning to main menu");
                                        break;
                                    }
                                    System.out.println("Would you like to view another dashboard? (Type yes or no)");
                                    responser = scan.nextLine();
                                    if (responser.equalsIgnoreCase("No") || !responser.equalsIgnoreCase("Yes")) {
                                        System.out.println("Returning to main menu");
                                    }
                                } else {
                                    System.out.println("There are no stores for you to view!");
                                    break;
                                }
                            } while (responser.equalsIgnoreCase("Yes"));
                        } catch (NumberFormatException e) {
                            System.out.println("Not a Valid Number!");
                            System.out.println("Returning to main menu");
                        }

                    } else if (mainMenuChoice == 4) {
                        // 4. Manage stores

                        String response;
                        int storeID;
                        int response1;
                        int resp;
                        boolean b;
                        try {
                            do {
                                System.out.println("Would you like to create a new store or edit a current store?");
                                System.out.println("1 - Edit Store\n2 - Create New Store");
                                resp = Integer.parseInt(scan.nextLine());
                                if (resp == 1) {
                                    System.out.println("Choose a store to edit");
                                    System.out.print(seller.formatStores());
                                    storeID = Integer.parseInt(scan.nextLine());
                                    boolean validityStore = seller.getStoreValid(storeID);
                                    if (!validityStore) {
                                        System.out.println("No such store exists!");
                                        System.out.println("Returning to main menu");
                                        break;
                                    } else {
                                        System.out.println("What would you like to change?");
                                        System.out.println("1 - Edit store name\n2 - Delete store");
                                        response1 = Integer.parseInt(scan.nextLine());
                                        if (response1 == 1) {
                                            System.out.println("Enter a new name");
                                            b = seller.changeStoreName(scan.nextLine(), storeID);
                                            if (b) {
                                                System.out.println("Success!");
                                            } else {
                                                System.out.println("ERROR: A store already exists with that name!");
                                            }
                                        } else if (response1 == 2) {
                                            seller.deleteStore(storeID);
                                            System.out.println("Store has been deleted!");
                                        } else {
                                            System.out.println("Invalid Input!");
                                            System.out.println("Returning to main menu");
                                            break;
                                        }
                                    }
                                } else if (resp == 2) {
                                    ArrayList<String> stores = seller.getStores();
                                    String newStoreName = "";
                                    String s1;
                                    loop:
                                    while (true) {
                                        System.out.println("Enter a Store Name");
                                        newStoreName = scan.nextLine();
                                        if (newStoreName.isEmpty()) {
                                            System.out.println("ERROR: Please enter a Store Name!");
                                            continue;
                                        }
                                        for (String s : stores) {
                                            s1 = s.substring(s.indexOf("Name:"), s.indexOf(">"));
                                            if (s1.equals("Name:" + newStoreName)) {
                                                System.out.println("ERROR: A store already exists with that name!");
                                                continue loop;
                                            }
                                        }
                                        break;
                                    }
                                    seller.createNewStore(newStoreName);
                                } else {
                                    System.out.println("Invalid Input!");
                                    System.out.println("Returning to main menu");
                                    break;
                                }
                                System.out.println("Would you like to edit again?");
                                response = scan.nextLine();
                                if (response.equalsIgnoreCase("No") || !response.equalsIgnoreCase("Yes")) {
                                    System.out.println("Returning to main menu");
                                }
                            } while (response.equalsIgnoreCase("Yes"));
                        } catch (NumberFormatException e) {
                            System.out.println("Not a Valid Number!");
                            System.out.println("Returning to main menu");
                        }

                    } else if (mainMenuChoice == 5) {
                        // 5. Choose users to block

                        int blocker = -1;
                        do {
                            System.out.println("Would you like to add or remove blocked users?");
                            System.out.println("1. Add\n2. Remove");
                            try {
                                blocker = Integer.parseInt(scan.nextLine());
                            } catch (NumberFormatException e) {
                                // Do nothing, if it doesn't work the value is already set to -1
                            }
                            if (blocker == 1) {
                                // Adding customers to wasBlockedBy in customerData and hasBlocked in sellerData
                                System.out.println("Please enter the ID of the customer that you want to block: ");
                                ArrayList<String> notBlockedCustomerNameArrayList = seller.getNotBlockedByArrayList();
                                if (!notBlockedCustomerNameArrayList.isEmpty()) {
                                    for (int i = 0; i < notBlockedCustomerNameArrayList.size(); i++) {
                                        System.out.println(notBlockedCustomerNameArrayList.get(i));
                                    }
                                    int blockCustomerIDs = -1;
                                    try {
                                        blockCustomerIDs = Integer.parseInt(scan.nextLine());
                                    } catch (NumberFormatException e) {
                                        System.out.println("Invalid input");
                                        break;
                                    }
                                    seller.addBlockedUser(blockCustomerIDs);
                                    System.out.println("Finished blocking!");
                                } else {
                                    System.out.println("You have no unblocked customers!");
                                    break;
                                }
                            } else if (blocker == 2) {
                                // Removing customers from wasBlockedBy in customerData and hasBlocked in sellerData
                                System.out.println("Please enter the ID of the customer that you want to unblock:");
                                ArrayList<String> blockedCustomerNameArrayList = seller.getBlockedCustomerNameList();
                                if (!blockedCustomerNameArrayList.isEmpty()) {
                                    for (int i = 0; i < blockedCustomerNameArrayList.size(); i++) {
                                        System.out.println(blockedCustomerNameArrayList.get(i));
                                    }
                                } else {
                                    System.out.println("You have no blocked customers!");
                                    break;
                                }
                                int customerIDToBeBlocked = Integer.parseInt(scan.nextLine());
                                seller.removeBlockedUser(customerIDToBeBlocked);
                                System.out.println("Finished unblocking!");
                            } else {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }

                            System.out.println("Do you want to block/unblock more people? (Type yes or no)");
                            String blockMore = scan.nextLine();
                            if (blockMore.equalsIgnoreCase("No")) {
                                break;
                            } else if (!blockMore.equalsIgnoreCase("Yes")) {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }
                        } while (true);

                    } else if (mainMenuChoice == 6) {
                        int invis;
                        do {
                            System.out.println("Would you like to add or remove users that see you as invisible?");
                            System.out.println("1. Add\n2. Remove");
                            invis = Integer.parseInt(scan.nextLine());
                            if (invis == 1) {
                                System.out.println("Please enter the ID of the customer that you want to see " +
                                        "as invisible:");
                                ArrayList<String> sellerFullCustomerNameArrayList = seller.getFullCustomerNameList();
                                ArrayList<String> seeAsInvisibleArrayList = seller.getInvisibleList();
                                ArrayList<String> seeAsVisibleArrayList = seller.getFullCustomerNameList();
                                ArrayList<Integer> acceptableInput = new ArrayList<>();

                                for (int i = 0; i < seeAsInvisibleArrayList.size(); i++) {
                                    if (seeAsVisibleArrayList.contains(seeAsInvisibleArrayList.get(i))) {
                                        seeAsVisibleArrayList.remove(seeAsInvisibleArrayList.get(i));
                                    }
                                }
                                if (!seeAsVisibleArrayList.isEmpty()) {
                                    for (int i = 0; i < seeAsVisibleArrayList.size(); i++) {
                                        System.out.println(seeAsVisibleArrayList.get(i));
                                        String[] splitString = seeAsVisibleArrayList.get(i).split(" - ");
                                        acceptableInput.add(Integer.parseInt(splitString[1]));
                                    }
                                } else {
                                    System.out.println("You have no visible customers!");
                                    break;
                                }

                                int invisCustomerID = -1;
                                try {
                                    invisCustomerID = Integer.parseInt(scan.nextLine());
                                    if (invisCustomerID % 2 != 0 || !acceptableInput.contains(invisCustomerID)) {
                                        // check to ensure that it's even
                                        throw new NumberFormatException();
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid input");
                                    break;
                                }
                                seller.addSeesAsInvisibleToSeller(invisCustomerID);
                                System.out.println("Finished! You will now see this customer as invisible!");
                            } else if (invis == 2) {
                                System.out.println("Please enter the ID of the invisible customer " +
                                        "that you want to see");
                                if (seller.getInvisibleList().isEmpty()) {
                                    System.out.println("You have no invisible customers!");
                                    break;
                                }
                                ArrayList<String> seeAsInvisibleArrayList = seller.getInvisibleList();
                                for (int i = 0; i < seeAsInvisibleArrayList.size(); i++) {
                                    System.out.println(seeAsInvisibleArrayList.get(i));
                                }
                                int invisCustomerID = -1;
                                try {
                                    invisCustomerID = Integer.parseInt(scan.nextLine());
                                    if (invisCustomerID % 2 != 0) {
                                        // check to see if it's even
                                        throw new NumberFormatException();
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid input");
                                    break;
                                }
                                seller.removeInvisibleUser(invisCustomerID);
                                System.out.println("Done!");
                            } else {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }

                            System.out.println("Do you want to change invisibility more? (Type yes or no)");
                            String blockMore = scan.nextLine();
                            if (blockMore.equalsIgnoreCase("No")) {
                                break;
                            } else if (!blockMore.equalsIgnoreCase("Yes")) {
                                System.out.println("Invalid input! Back to the main manu!");
                                break;
                            }
                        } while (true);
                        // 6. Choose users to become invisible to
                    } else if (mainMenuChoice == 7) {
                        String response;
                        do {
                            System.out.println("What do you want to edit?");
                            System.out.println("1. Username\n2. Password\n3. Email");
                            int responseTwo = Integer.parseInt(scan.nextLine());
                            Boolean success;
                            if (responseTwo == 1) {
                                System.out.println("Enter your new username");
                                String newUsername = scan.nextLine();
                                success = seller.editSellerUsername(newUsername);
                                if (success)
                                    System.out.println("Successful username change made.");
                                else
                                    System.out.println("ERROR: That username is taken!");
                            } else if (responseTwo == 2) {
                                System.out.println("Enter your new password");
                                String newPassword = scan.nextLine();
                                seller.editPassword(newPassword);
                                System.out.println("Successful password change made.");
                            } else if (responseTwo == 3) {
                                System.out.println("Enter your new email");
                                String newEmail = scan.nextLine();
                                success = seller.editEmail(newEmail);
                                if (success)
                                    System.out.println("Successful email change made.");
                                else
                                    System.out.println("ERROR: That email is already associated " +
                                            "with another account!");
                            } else {
                                System.out.println("Invalid input!");
                                System.out.println("Returning to main menu");
                                break;
                            }
                            System.out.println("Would you like to edit again? (Type yes or no)");
                            response = scan.nextLine();
                            if (!response.equalsIgnoreCase("yes") && !response.equalsIgnoreCase("no")) {
                                System.out.println("Invalid input!");
                                System.out.println("Returning to main menu");
                                break;
                            }
                        } while (response.equalsIgnoreCase("Yes"));
                        // 7. Edit account
                    } else if (mainMenuChoice == 8) {

                        // 8. Delete Account
                        String response = "";
                        do {
                            System.out.println("Do you want to delete this account? (Type yes or no)");
                            response = scan.nextLine();
                            if (response.equalsIgnoreCase("Yes")) {
                                System.out.print("Confirm your email to delete your account\n Email: ");
                                String responseTwo = scan.nextLine();
                                if (responseTwo.equals(seller.getEmail())) {
                                    seller.deleteAccount(responseTwo);
                                    loggedIn = false;
                                } else {
                                    System.out.println("ERROR: Incorrect email");
                                }
                            } else if (response.equalsIgnoreCase("No")) {
                                break;
                            } else
                                System.out.println("Please enter a valid input!");
                        } while (!(response.equalsIgnoreCase("Yes")) && !(response.equalsIgnoreCase("No")));
                    } else if (mainMenuChoice == 9) {
                        // 9. Log out
                        loggedIn = false;
                    }
                }
            }
        }
    }
}

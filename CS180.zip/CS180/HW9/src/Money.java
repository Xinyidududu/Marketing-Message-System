public interface Money {
    public int convert(Money money);

    public boolean acceptedVending();

    public double getValue();

}

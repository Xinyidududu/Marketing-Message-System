public class TenDollar extends DollarBill{
    public TenDollar() {
        super( 10, "Alexander Hamilton");
    }
}

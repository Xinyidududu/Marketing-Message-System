public class HonorPledge {
    public static void main(String[] args) {
       int x;
       double y = 12.0;
       x = (int) (y/5);


        System.out.println(x);
        System.out.println("As a Boilermaker pursuing academic excellence, " +
                "I pledge to be honest and true in all that I do.\n" +
                "                                \n" +
                "Accountable together - We are Purdue.\n" +
                "                                ");
    }
}
import java.util.Scanner;

public class MusicRecommender {

    public static final String WELCOME_MESSAGE = "Welcome to the Music Recommender!";
    public static final String INITIAL_SONG = "Do you want to listen to a song?";
    public static final String HAPPY = "Are you feeling happy?";
    public static final String CLAP_ALONG = "Do you want to clap along?";
    public static final String SING_OUT = "Do you want to sing out?";
    public static final String DANCE = "Do you want to dance?";
    public static final String SAD = "Are you feeling sad?";
    public static final String LYRICS = "Do you want lyrics?";
    public static final String WORRIED = "Are you feeling worried?";
    public static final String CALM = "Are you feeling calm?";
    public static final String COMPLICATED = "Are your feelings more complicated" + " than this program can handle?";
    public static final String CONTINUE_WORRIED = "Do you want to keep " + "feeling worried?";
    public static final String GOODBYE_MESSAGE = "Thank you for using" + " the Music Recommender!";

    public static final String SONG_ONE = "Play \"Happy\" by Pharrell Williams";
    public static final String SONG_TWO = "Play \"If you want to Sing Out, Sing Out\" by Cat Stevens";
    public static final String SONG_THREE = "Play \"Uptown Funk\" by Mark Ronson featuring Bruno Mars";
    public static final String SONG_FOUR = "Play \"La finta giardiniera, K. 196: Ouverture. Allegro molto\" by Mozart";
    public static final String SONG_FIVE = "Play \"Hurt\" by Trent Reznor, as performed by Johnny Cash";
    public static final String SONG_SIX = "Play Theme from Schindler's List";
    public static final String SONG_SEVEN = "Play \"Aben bog\" by Bremer/McCoy";
    public static final String SONG_EIGHT = "Play \"Complicated\" by Avril Lavigne";
    public static final String SONG_NINE = "Play \"A Witch Stole Sam\" by Mark Korven" + " from The Witch Original Soundtrack";
    public static final String SONG_TEN = "Play \"Don't worry. Be Happy\" by Bobby McFerrin";

    // ------------------------- DO NOT MODIFY ABOVE -------------------------

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String inputAnswer;
        String moodAnswer;
        String clapAnswer;
        String singAnswer;
        String danceAnswer;
        String sadAnswer;
        String lyricsAns;
        String worryAns;
        String calmAns;
        String compAns;
        String keepWorry;
        System.out.println(WELCOME_MESSAGE);
        System.out.println(INITIAL_SONG);
        inputAnswer = scan.nextLine();


        if (inputAnswer.toUpperCase().equals("NO")) {
            System.out.println(GOODBYE_MESSAGE);
            //return;

        } else if (inputAnswer.toUpperCase().equals("YES")) {
            System.out.println(HAPPY);
            moodAnswer = scan.nextLine();

            if (moodAnswer.toUpperCase().equals("YES")) {
                System.out.println(CLAP_ALONG);
                clapAnswer = scan.nextLine();

                if (clapAnswer.toUpperCase().equals("YES")) {
                    System.out.println(SONG_ONE);
                    System.out.println(GOODBYE_MESSAGE);

                } else if (clapAnswer.toUpperCase().equals("NO")) {
                    System.out.println(SING_OUT);
                    singAnswer = scan.nextLine();

                    if (singAnswer.toUpperCase().equals("YES")) {
                        System.out.println(SONG_TWO);
                        System.out.println(GOODBYE_MESSAGE);

                    } else if (singAnswer.toUpperCase().equals("NO")) {
                        System.out.println(DANCE);
                        danceAnswer = scan.nextLine();

                        if (danceAnswer.toUpperCase().equals("YES")) {
                            System.out.println(SONG_THREE);
                            System.out.println(GOODBYE_MESSAGE);

                        } else if (danceAnswer.toUpperCase().equals("NO")) {
                            System.out.println(SONG_FOUR);
                            System.out.println(GOODBYE_MESSAGE);
                        }
                    }

                }

            } else if (moodAnswer.toUpperCase().equals("NO")) {
                System.out.println(SAD);
                sadAnswer = scan.nextLine();

                if (sadAnswer.toUpperCase().equals("YES")) {
                    System.out.println(LYRICS);
                    lyricsAns = scan.nextLine();

                    if (lyricsAns.toUpperCase().equals("YES")) {
                        System.out.println(SONG_FIVE);
                        System.out.println(GOODBYE_MESSAGE);
                    } else if (lyricsAns.toUpperCase().equals("NO")) {
                        System.out.println(SONG_SIX);
                        System.out.println(GOODBYE_MESSAGE);
                    }

                } else if (sadAnswer.toUpperCase().equals("NO")) {
                    System.out.println(WORRIED);
                    worryAns = scan.nextLine();

                    if (worryAns.toUpperCase().equals("NO")) {
                        System.out.println(CALM);
                        calmAns = scan.nextLine();
                        if (calmAns.toUpperCase().equals("YES")) {
                            System.out.println(SONG_SEVEN);
                            System.out.println(GOODBYE_MESSAGE);
                        } else if (calmAns.toUpperCase().equals("NO")) {
                            System.out.println(COMPLICATED);
                            compAns = scan.nextLine();
                            if (compAns.toUpperCase().equals("YES")) {
                                System.out.println(SONG_EIGHT);
                                System.out.println(GOODBYE_MESSAGE);
                            } else {
                                System.out.println(GOODBYE_MESSAGE);
                            }
                        }
                    } else if (worryAns.toUpperCase().equals("YES")) {
                        System.out.println(CONTINUE_WORRIED);
                        keepWorry = scan.nextLine();

                        if (keepWorry.toUpperCase().equals("YES")) {
                            System.out.println(SONG_NINE);
                            System.out.println(GOODBYE_MESSAGE);
                        } else if (keepWorry.toUpperCase().equals("NO")) {
                            System.out.println(SONG_TEN);
                            System.out.println(GOODBYE_MESSAGE);

                        }
                    }
                }
            }
        }
    }
}


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String holiday = "";
        Scanner scanner = new Scanner(System.in);

        System.out.println("Pick a number between 1-6 to select a holiday!");
        System.out.println("1. July");
        System.out.println("2. September");
        System.out.println("3. October");
        System.out.println("4. November");
        System.out.println("5. January");
        System.out.println("6. March");
        int inputDay = scanner.nextInt();
        if (inputDay == 1) {
            holiday = "Independence Day Holiday";
            System.out.printf("The holiday is: %s!\n", holiday);
        } else if (inputDay == 2) {
            holiday = "Labor Day";
            System.out.printf("The holiday is: %s!\n", holiday);
        } else if (inputDay == 3) {
            holiday = "October Break";
            System.out.printf("The holiday is: %s!\n", holiday);
        } else if (inputDay == 4) {
            holiday = "Thanksgiving Vacation";
            System.out.printf("The holiday is: %s!\n", holiday);
        } else if (inputDay == 5) {
            holiday = "Martin Luther King Jr. Day";
            System.out.printf("The holiday is: %s!\n", holiday);
        } else if (inputDay == 6) {
            holiday = "Spring Vacation";
            System.out.printf("The holiday is: %s!\n", holiday);

        } else {
            System.out.println("That's not a valid number!");

        }

    }

}





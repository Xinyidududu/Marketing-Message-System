public interface Identifiable {
    String getName();
}

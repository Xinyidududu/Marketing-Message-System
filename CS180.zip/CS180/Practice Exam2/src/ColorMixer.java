import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


public class ColorMixer {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the filename of the color map.");
        String colorFile = scan.nextLine();
        Color[] arr = readFile(colorFile);
        if (arr == null) {
            return;
        }
        System.out.println("Enter the filename to output the colors to.");
        String inputFile = scan.nextLine();
        if (!writeFile(arr, inputFile)) {
            System.out.println("There was an error writing to the file.");
        } else {
            System.out.println("The file was written to!");
        }
    }

    public static Color[] readFile(String fileName) {
        int lineNumb = 0;
        int count = 0;
        int red = -1;
        int green = -1;
        int blue = -1;
        Color color;
        ArrayList<Color> colorArrayList = new ArrayList<>();
        Color[] colors;
        try {
            String line;
            BufferedReader bfr = new BufferedReader(new FileReader(fileName));
            while ((line = bfr.readLine())!= null) {
                count++;
                lineNumb++;
                if (count == 4) {
                    color = new Color(red, green, blue);
                    colorArrayList.add(color);
                    red = -1;
                    green = -1;
                    blue = -1;
                    count = 1;
                }

                if (count == 1) {
                    red = Integer.parseInt(line);
                }
                if (count == 2) {
                    green = Integer.parseInt(line);
                }
                if (count == 3) {
                    blue = Integer.parseInt(line);
                }
                //count++;
            }
            if (count == 3) {
                color = new Color(red, green, blue);
                colorArrayList.add(color);
            }
            if (lineNumb % 3 != 0) {
                System.out.println("Either the file doesn't exist or the file is in the wrong format!");
                return null;
            }

            colors = new Color[colorArrayList.size()];
            for (int i = 0; i < colors.length; i++) {
                colors[i] = colorArrayList.get(i);
            }
            bfr.close();
            return colors;
        } catch (FileNotFoundException e) {
            System.out.println("Either the file doesn't exist or the file is in the wrong format!");
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean writeFile(Color[] colors, String filename) {
        //colors = readFile(filename);
        try {
            BufferedWriter bfw = new BufferedWriter(new FileWriter(filename));
            for (Color color : colors) {
                bfw.write(color.toString() + "\n");
            }
            bfw.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}

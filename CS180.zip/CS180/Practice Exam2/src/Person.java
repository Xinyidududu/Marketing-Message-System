import java.util.Objects;

public class Person implements Identifiable {
    private final String name;
    private final int age;

    public Person(String name, int age) {
        if (name == null) {
            throw new NullPointerException();
        }
        if (age < 0) {
            throw new IllegalArgumentException();
        }
        this.name = name;
        this.age = age;
    }

    public Person(Person person) {
        if (person == null) {
            throw new NullPointerException();
        }
        this.name = person.name;
        this.age = person.age;
    }

    @Override
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person)) return false;
        Person person = (Person) o;
        return age == person.age && name.equalsIgnoreCase(person.name);
    }

    public String toString() {
        return "Person<name=" + this.name + ", age=" + this.age + ">" + "\n";
    }

}

import java.util.Objects;

public class Employee extends Person {
    private final int hourlyRate;

    public Employee(String name, int age, int hourlyRate) {
        super(name, age);
        if (hourlyRate < 0) {
            throw new IllegalArgumentException();
        }
        this.hourlyRate = hourlyRate;
    }

    public Employee(Employee employee) {
        super(employee);
        if (employee == null) {
            throw new NullPointerException();
        }
        this.hourlyRate = employee.hourlyRate;
    }

    public int getHourlyRate() {
        return hourlyRate;
    }

    public int calculateIncome(int hours) {
        if (hours < 0) {
            throw new IllegalArgumentException();
        }
        return (this.hourlyRate * hours);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        //if (!super.equals(o)) return false;
        Employee employee = (Employee) o;
        return getAge() == employee.getAge()
                && getName().equalsIgnoreCase(employee.getName())
                && hourlyRate == employee.hourlyRate;
    }

    @Override
    public String toString() {
        return "Employee<name=" + getName() +
                ", age=" + getAge() + ", hourlyRate=" + this.hourlyRate +
                ">" + "\n";
    }
}

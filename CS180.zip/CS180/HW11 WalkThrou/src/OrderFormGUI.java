import javax.swing.*;

public class OrderFormGUI {
    public static void main(String[] args) {
        /** DO NOT CHANGE VALUES BELOW **/
        boolean hoodieInStock = true;
        boolean tshirtInStock = false;
        boolean longsleeveInStock = true;
        String item = "";
        int quantity = 0;
        String name = "";
        /** DO NOT CHANGE VALUES ABOVE **/

        int keepRun;
        do {
            do {
                String[] options = {"Hoodie", "T-shirt", "Long sleeve"};
                item = (String) JOptionPane.showInputDialog(null, "Select item style "
                        , "Order Form",
                        JOptionPane.PLAIN_MESSAGE, null, options, null);
                if (item.equals("T-shirt")) {
                    JOptionPane.showMessageDialog(null, "Error! T-shirt is out of stock."
                            , "Order Form",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            } while (item.equals("T-shirt"));



            boolean sb;
            do {
                try {
                    quantity = Integer.parseInt(JOptionPane.showInputDialog(null
                            , "Enter quantity", "Order Form",
                            JOptionPane.QUESTION_MESSAGE));
                    //quantity++;
                    sb = true;
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Error! Please enter a number."
                            , "Order Form",
                            JOptionPane.INFORMATION_MESSAGE);
                    sb = false;
                    continue;
                }
                if (quantity < 1) {
                    JOptionPane.showMessageDialog(null
                            , "Error! Please enter a number greater than 0", "Order Form",
                            JOptionPane.INFORMATION_MESSAGE);
                    sb = false;
                }
            } while (!sb);

            int index;
            do {
                name = JOptionPane.showInputDialog(null, "Enter your Name", "Order Form",
                        JOptionPane.QUESTION_MESSAGE);
                index = name.indexOf(" ");
                if (index == -1) {
                    JOptionPane.showMessageDialog(null, "Error! Please enter a name with space."
                            , "Order Form",
                            JOptionPane.INFORMATION_MESSAGE);
                }

            } while (index == -1);

            /** Order Confirmation Message **/
            String resultMessage = "Name: " + name + "\nItem: " + item + "\nQuantity: " + quantity;
            JOptionPane.showMessageDialog(null, resultMessage, "Order Confirmation"
                    , JOptionPane.INFORMATION_MESSAGE);

            keepRun = JOptionPane.showConfirmDialog(null
                    , "Would you like to place another order?", "Order Form", JOptionPane.YES_NO_OPTION);
        } while (keepRun == JOptionPane.YES_OPTION);
    }
}

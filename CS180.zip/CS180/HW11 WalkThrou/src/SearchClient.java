import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Objects;

public class SearchClient {
    public static void main(String[] args) throws IOException {

        int realNumber;
        JOptionPane.showMessageDialog(null, "Welcome to database searching program",
                "Database searching", JOptionPane.INFORMATION_MESSAGE);
        String hostName;
        //do {
        hostName = JOptionPane.showInputDialog(null, "What is your host name?",
                "Database searching", JOptionPane.QUESTION_MESSAGE);
        if (hostName == null) {
            return;
        }
        if (hostName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error! Please enter a valid host name.",
                    "Database searching", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String portNumber;
        try {
            portNumber = JOptionPane.showInputDialog(null, "What is your port number?",
                    "Database searching", JOptionPane.QUESTION_MESSAGE);
            if (portNumber == null) {
                return;
            }
            realNumber = Integer.parseInt(portNumber);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error! Please enter a number.",
                    "Database searching", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (realNumber <= -1) {
            JOptionPane.showMessageDialog(null, "Error! Please enter a valid port number.",
                    "Database searching", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!hostName.equals("localhost") || realNumber != 4242) {
            JOptionPane.showMessageDialog(null,
                    "Error! Connection is not established successfully", "Database searching",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        Socket socket = new Socket(hostName, realNumber);
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter writer = new PrintWriter(socket.getOutputStream());
        JOptionPane.showMessageDialog(null, "Connection is established successfully",
                "Database searching", JOptionPane.INFORMATION_MESSAGE);

        int again;

        do {
            String inputText;
            do {
                inputText = JOptionPane.showInputDialog(null, "Enter your search text",
                        "Database searching", JOptionPane.QUESTION_MESSAGE);
                if (inputText == null) {
                    return;
                }
                if (inputText.isEmpty() || inputText.equals(";")) {
                    JOptionPane.showMessageDialog(null,
                            "Error! Enter an input.", "Database searching",
                            JOptionPane.ERROR_MESSAGE);
                }
            } while (inputText.isEmpty());

            ArrayList<String> dropDown = new ArrayList<>();
            writer.println(inputText);//send inputText to the server
            writer.flush();
            String line = reader.readLine();
            System.out.println(line);
            //if(line != null && !line.equals("") && !line.equals("null")) {
            if (!line.equals("[]") && !line.equals("")) {
                //!line.equals("") ?
                line = line.substring(1, line.length() - 1);
                if (line.contains(",")) {//convert line(string) into dropDown without ";"
                    String[] strArray = line.split(",");
                    for (String s : strArray) {
                        dropDown.add(s.trim());
                    }
                } else {
                    dropDown.add(line);
                }//check if the line is empty.
            } else {
                System.out.println("is empty"); // for checking
            }
            if (dropDown.size() != 0) {//if i got some results.
                System.out.println("size is " + dropDown.size());
                String[] realDropDown = dropDown.toArray(String[]::new);
                String select = (String) JOptionPane.showInputDialog(null, "Select your result",
                        "Database searching", JOptionPane.QUESTION_MESSAGE, null, realDropDown,
                        realDropDown[0]);
                if (select == null) {
                    return;
                }
                //print all info here;
                String allInfo;
                writer.println(select);
                writer.flush();
                allInfo = reader.readLine();
                JOptionPane.showMessageDialog(null, allInfo,
                        "Database searching", JOptionPane.INFORMATION_MESSAGE);
                System.out.println(allInfo);
                //play again?
                again = JOptionPane.showConfirmDialog(null, "Do you want to search again?",
                        "Database searching", JOptionPane.YES_NO_OPTION);
                if (again == JOptionPane.NO_OPTION) {
                    String againString = String.valueOf(again);
                    writer.println(againString);
                    writer.flush();
                    writer.close();
                    reader.close();
                    JOptionPane.showMessageDialog(null, "See you next time!",
                            "Database searching", JOptionPane.INFORMATION_MESSAGE);
                    return;
                } else if (again == JOptionPane.YES_OPTION) {
                    String againString = String.valueOf(again);
                    writer.println(againString);
                    writer.flush();
                }
            } else {//if i get nothing.
                System.out.println("in error");
                JOptionPane.showMessageDialog(null,
                        "Error! Cannot find anything!", "Database searching",
                        JOptionPane.ERROR_MESSAGE);
                again = JOptionPane.showConfirmDialog(null, "Do you want to search again?",
                        "Database searching", JOptionPane.YES_NO_OPTION);
                if (again == JOptionPane.NO_OPTION) {
                    String againString = String.valueOf(again);
                    writer.println(againString);
                    writer.flush();
                    writer.close();
                    reader.close();
                    JOptionPane.showMessageDialog(null, "See you next time!",
                            "Database searching", JOptionPane.INFORMATION_MESSAGE);
                    return;
                } else if (again == JOptionPane.YES_OPTION) {
                    String againString = String.valueOf(again);
                    writer.println(againString);
                    writer.flush();
                }
            }
        } while (again == JOptionPane.YES_OPTION);
    }
}
//again problem
//empty problem

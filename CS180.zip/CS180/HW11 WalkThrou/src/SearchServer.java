import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

public class SearchServer {
    //in 1st method, put all the title into an array, and return all the title that relevant the input
    //in 2nd method, get the

    public static void main(String[] args) {
        try {
            boolean searchAgain = true;
            ServerSocket serverSocket = new ServerSocket(4242);
            Socket socket = serverSocket.accept();
            BufferedReader bfr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter ptw = new PrintWriter(socket.getOutputStream());
            while (searchAgain) {
                String input = bfr.readLine();//user's first input
                System.out.println(input);
                String[] titles = findTitlesContaining(input);
                ptw.println(Arrays.toString(titles));
                ptw.flush();

                int again;

                String realInput = bfr.readLine();//user actually choose a word
                String description = findDescription(realInput);
                ptw.println(description);
                ptw.flush();

                String againNumb = bfr.readLine();
                again = Integer.parseInt(againNumb);
                if (again == 1) {
                    searchAgain = false;
                }
            }
            bfr.close();
            ptw.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static String[] findTitlesContaining(String keyword) throws IOException {
        ArrayList<String> matchingTitles = new ArrayList<>();
        File file = new File("/Users/myfile/Documents/CS180/HW11 WalkThrou/searchDatabase");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] content = line.split(";");
            String title = content[1];
            if (line.contains(keyword) || line.toLowerCase().contains(keyword.toLowerCase())) {
                matchingTitles.add(title);
            }
        }
        br.close();
        //matchingTitles.isEmpty() ? null : matchingTitles.toArray(String[]::new);
        return matchingTitles.toArray(String[]::new);
    }

    public static String findDescription(String keyword) throws IOException {
        System.out.println(keyword);
        File file = new File("/Users/myfile/Documents/CS180/HW11 WalkThrou/searchDatabase");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        String descirption = "";
        while ((line = br.readLine()) != null) {
            System.out.println(line);
            String[] content = line.split(";");
            String title = content[1];
            String Info = content[2];
            if (title.toLowerCase().equals(keyword.toLowerCase())) {
                descirption = Info;
            }
        }
        br.close();
        System.out.println("description: " + descirption);
        return descirption;
    }


}

import java.util.ArrayList;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class WaterPark implements Park {
    private double admissionCost;
    private boolean indoor;
    private double land;
    private boolean lazyRiver;
    private String name;
    private boolean outdoor;
    private ArrayList<Ride> rides;
    private boolean[] seasons;
    private boolean wavePool;

    public WaterPark(String name, double admissionCost, double land, ArrayList<Ride> rides, boolean indoor,
                     boolean outdoor, boolean lazyRiver, boolean wavePool, boolean[] seasons) {
        this.admissionCost = admissionCost;
        this.indoor = indoor;
        this.land = land;
        this.lazyRiver = lazyRiver;
        this.name = name;
        this.outdoor = outdoor;
        this.rides = rides;
        this.seasons = seasons;
        this.wavePool = wavePool;
    }

    public boolean isLazyRiver() {
        return lazyRiver;
    }

    public void setLazyRiver(boolean lazyRiver) {
        this.lazyRiver = lazyRiver;
    }

    public boolean isWavePool() {
        return wavePool;
    }

    public void setWavePool(boolean wavePool) {
        this.wavePool = wavePool;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setAdmissionCost(double admissionCost) {
        this.admissionCost = admissionCost;
    }

    @Override
    public double getAdmissionCost() {
        return admissionCost;
    }

    @Override
    public void enlarge(double addedLand, double maxLand, boolean addedIndoor,
                        boolean addedOutdoor) throws SpaceFullException {
        if (land + addedLand >= maxLand) {
            throw new SpaceFullException("There is no more land to use for this park!");
        } else {
            land += addedLand;
        }
        if (!indoor && addedIndoor) {
            indoor = true;
        }
        if (!outdoor && addedOutdoor) {
            outdoor = true;
        }

    }

    @Override
    public double getLand() {
        return land;
    }

    @Override
    public void addRide(Ride ride) throws WrongRideException {
        if (ride instanceof Rollercoaster) {
            throw new WrongRideException("A waterpark can only have waterslide rides!");
        } else {
            rides.add(ride);
        }
    }

    @Override
    public void removeRide(Ride ride) {
        rides.remove(ride);
    }

    @Override
    public ArrayList<Ride> getRides() {
        return rides;
    }

    @Override
    public boolean isIndoor() {
        return indoor;
    }

    @Override
    public boolean isOutdoor() {
        return outdoor;
    }

    @Override
    public void setSeasons(boolean[] seasons) {
        this.seasons = seasons;
    }

    @Override
    public boolean[] getSeasons() {
        return seasons;
    }

    public void modifyRide(Ride ride, String newName, String newColor,
                           int newMinHeight, int newMaxRiders, double newSplashDepth) {
        int index = rides.indexOf(ride);
        ride.setName(newName);
        ride.setColor(newColor);
        ride.setMinHeight(newMinHeight);
        ride.setMaxRiders(newMaxRiders);
        Waterslide waterslide = (Waterslide) ride;
        waterslide.setSplashDepth(newSplashDepth);
        rides.set(index, ride);

    }

    @Override
    public void close() {
        this.name = "";
        this.admissionCost = 0;
        this.land = 0;
        this.rides = null;
        this.seasons = null;
        this.indoor = false;
        this.outdoor = false;
        this.lazyRiver = false;
        this.wavePool = false;
    }
}

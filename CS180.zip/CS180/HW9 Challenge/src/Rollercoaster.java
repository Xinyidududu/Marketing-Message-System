import java.util.Objects;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class Rollercoaster extends Ride {
    private boolean simulated;

    public Rollercoaster(String name,
                         String color,
                         int minHeight,
                         int maxRiders,
                         boolean simulated) {
        super(name, color, minHeight, maxRiders);
        this.simulated = simulated;
    }

    public boolean isSimulated() {
        return simulated;
    }

    public void setSimulated(boolean simulated) {
        this.simulated = simulated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Rollercoaster that)) return false;
        return Objects.equals(getMinHeight(), that.getMinHeight()) &&
                getMaxRiders() == that.getMaxRiders() &&
                simulated == that.simulated &&
                Objects.equals(getName(), that.getName()) &&
                Objects.equals(getColor(), that.getColor());
    }


    @Override
    public String toString() {
        String simulatedStr = Boolean.toString(simulated);
        return "Name: " + getName() + "\n" +
                "Color: " + getColor() + "\n" +
                "MinHeight: " + getMinHeight() + " inches" + "\n" +
                "MaxRiders: " + getMaxRiders() + "\n" +
                "Simulated: " + simulatedStr;
    }
}

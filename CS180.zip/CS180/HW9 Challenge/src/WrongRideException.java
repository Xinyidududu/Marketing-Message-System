/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */

public class WrongRideException extends Exception {
    public WrongRideException(String message) {
        super(message);
    }
}

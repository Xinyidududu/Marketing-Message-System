import java.util.ArrayList;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */

public class AmusementPark implements Park {
    private String name;
    private double admissionCost;
    private double land;
    private ArrayList<Ride> rides;
    private boolean indoor;
    private boolean outdoor;
    private boolean arcade;
    private boolean bowling;
    private boolean[] seasons;

    public AmusementPark(String name, double admissionCost, double land,
                         ArrayList<Ride> rides, boolean indoor, boolean outdoor,
                         boolean arcade, boolean bowling, boolean[] seasons) {
        this.name = name;
        this.admissionCost = admissionCost;
        this.land = land;
        this.rides = rides;
        this.indoor = indoor;
        this.outdoor = outdoor;
        this.arcade = arcade;
        this.bowling = bowling;
        this.seasons = seasons;
    }

    public boolean isArcade() {
        return arcade;
    }

    public void setArcade(boolean arcade) {
        this.arcade = arcade;
    }

    public boolean isBowling() {
        return bowling;
    }

    public void setBowling(boolean bowling) {
        this.bowling = bowling;
    }

    public double getAdmissionCost() {
        return admissionCost;
    }

    public void setAdmissionCost(double admissionCost) {
        this.admissionCost = admissionCost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLand() {
        return land;
    }

    public void addRide(Ride ride) throws WrongRideException {
        if (ride instanceof Waterslide) {
            throw new WrongRideException("An amusement park can only have rollercoaster rides!");
        } else {
            rides.add(ride);
        }
    }

    public void removeRide(Ride ride) {
        rides.remove(ride);
    }

    public ArrayList<Ride> getRides() {
        return rides;
    }

    public boolean isIndoor() {
        return indoor;
    }

    public boolean isOutdoor() {
        return outdoor;
    }

    public void setSeasons(boolean[] seasons) {
        this.seasons = seasons;
    }

    public boolean[] getSeasons() {
        return seasons;
    }

    public void enlarge(double addedLand, double maxLand, boolean addedIndoor,
                        boolean addedOutdoor) throws SpaceFullException {
        if (land + addedLand >= maxLand) {
            throw new SpaceFullException("There is no more land to use for this park!");
        } else {
            land += addedLand;
        }
        if (!indoor && addedIndoor) {
            indoor = true;
        }
        if (!outdoor && addedOutdoor) {
            outdoor = true;
        }
    }

    public void modifyRide(Ride ride, String newName, String newColor,
                           int newMinHeight, int newMaxRiders, boolean newSimulated) {
        int index = rides.indexOf(ride);
        ride.setName(newName);
        ride.setColor(newColor);
        ride.setMinHeight(newMinHeight);
        ride.setMaxRiders(newMaxRiders);
        Rollercoaster rollercoaster = (Rollercoaster) ride;//把ride的dataType转换成Rollercoaster的这样就可以进入它的field
        rollercoaster.setSimulated(newSimulated);
        rides.set(index, ride);
    }

    public void close() {
        this.name = "";
        this.admissionCost = 0;
        this.land = 0;
        this.rides = null;
        this.seasons = null;
        this.indoor = false;
        this.outdoor = false;
        this.bowling = false;
        this.arcade = false;
    }

}

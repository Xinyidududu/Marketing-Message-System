import java.util.Objects;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */

public class Ride {
    private String name;
    private String color;
    private int minHeight;
    private int maxRiders;

    public Ride() {
        this.name = "";
        this.color = "";
        this.minHeight = 0;
        this.maxRiders = 0;
    }

    public Ride(String name,
                String color,
                int minHeight,
                int maxRiders) {
        this.name = name;
        this.color = color;
        this.minHeight = minHeight;
        this.maxRiders = maxRiders;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getMinHeight() {
        return minHeight;
    }

    public void setMinHeight(int minHeight) {
        this.minHeight = minHeight;
    }

    public int getMaxRiders() {
        return maxRiders;
    }

    public void setMaxRiders(int maxRiders) {
        this.maxRiders = maxRiders;
    }

    public boolean equals(Object o) {
        if (this == o)//Step 1 check if both of objs are the same obj?
            return true;
        if (!(o instanceof Ride))
            return false; //Step 2 check if the o is in the ride class
        Ride ride = (Ride) o; //step 3 cast o in ride class in order to use ride's method or access ride class
        return Objects.equals(name, ride.name) &&
                Objects.equals(color, ride.color) &&
                Objects.equals(minHeight, ride.minHeight) &&
                Objects.equals(maxRiders, ride.maxRiders); // step4 use the method compare them

    }

    @Override
    public String toString() {
        return "Name: " + name + "\n" +
                "Color: " + color + "\n" +
                "MinHeight: " + minHeight  + " inches" + "\n" +
                "MaxRiders: " + maxRiders;
    }
}


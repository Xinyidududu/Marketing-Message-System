import java.util.Objects;


/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class Waterslide extends Ride {
    private double splashDepth;

    public Waterslide(String name, String color, int minHeight, int maxRiders, double splashDepth) {
        super(name, color, minHeight, maxRiders);
        this.splashDepth = splashDepth;
    }

    public double getSplashDepth() {
        return splashDepth;
    }

    public void setSplashDepth(double splashDepth) {
        this.splashDepth = splashDepth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Waterslide that = (Waterslide) o;
        return getMinHeight() == that.getMinHeight() &&
                getMaxRiders() == that.getMaxRiders() &&
                splashDepth == that.splashDepth &&
                Objects.equals(getName(), that.getName()) &&
                Objects.equals(getColor(), that.getColor());
        //return super.equals(o) && Objects.equals(splashDepth, this.splashDepth);
    }

    @Override
    public String toString() {
        String spl = Double.toString(splashDepth);
        return "Name: " + getName() + "\n" +
                "Color: " + getColor() + "\n" +
                "MinHeight: " + getMinHeight() + " inches"+ "\n" +
                "MaxRiders: " + getMaxRiders() + "\n"
                + "SplashDepth: " + spl + " feet";
    }
}

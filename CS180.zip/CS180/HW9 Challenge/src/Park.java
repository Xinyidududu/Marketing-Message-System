import java.util.ArrayList;
/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */

public interface Park {
    void setName(String name);

    String getName();

    void setAdmissionCost(double admissionCost);

    double getAdmissionCost();

    void enlarge(double addedLand, double maxLand,
                 boolean addedIndoor, boolean addedOutdoor) throws SpaceFullException;

    double getLand();

    void addRide(Ride ride) throws WrongRideException;

    void removeRide(Ride ride);

    ArrayList<Ride> getRides();

    boolean isIndoor();

    boolean isOutdoor();

    void setSeasons(boolean[] seasons);

    boolean[] getSeasons();

    void close();


}
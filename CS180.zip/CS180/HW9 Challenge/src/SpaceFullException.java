/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class SpaceFullException extends Exception {
    public SpaceFullException(String message) {
        super(message);
    }
}

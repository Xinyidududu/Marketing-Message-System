import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Student Full Name:");
        String FirstName = scanner.next();
        String LastName = scanner.nextLine();
        System.out.println("Enter Student Mobile Number:");
        String MobileNumber = scanner.nextLine();
        scanner.nextLine();
        System.out.println("Enter Student ID Number (10 digits):");
        String ID = scanner.nextLine();
        System.out.println("Enter Insurance Provider Name:");
        String Insurance = scanner.nextLine();
        System.out.println("Enter Time of Day:");
        int Time = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Body Temperature (In F):");
        double F = scanner.nextDouble();
        scanner.nextLine();
        System.out.println("Enter Blood Pressure:");
        String Pressure = scanner.nextLine();
        System.out.println("Enter Heart Rate:");
        int Rate = scanner.nextInt();
        String s1 = FirstName.toUpperCase();
        String[] s2 = MobileNumber.split("-");
        int num1 = Integer.parseInt(s2[0]);
        int num2 = Integer.parseInt(s2[1]);
        int num3 = Integer.parseInt(s2[2]);
        int sum = num1 + num2 + num3;
        String s3 = ID.substring(7);
        System.out.println(s3);
        String charValue = Insurance.substring(0, 1);
        if (Time > 1259)
            Time = Time - 1200;
        int Time1 = Time / 100;
        int Time2 = (Time / 10) - (Time1 * 10);
        int Time3 = Time - ((Time / 10) * 10);
        String Time4 = Integer.toString(Time1);
        if (Time1 < 10) ;
        Time4 = "0" + Time4;
        Double C = (F - 32) * (5 / 9.0);
        int s5 = Insurance.charAt(0);
        int s6 = Insurance.charAt(1);

        System.out.println("Code: " + s1 + "|" + sum + "|" + s3 + "|" + s5 + s6);
        System.out.println("Time:" + Time4 + ":" + Time2 + Time3);
        System.out.println("Vital:" + String.format("%.2f", F) + "F|" + String.format("%.2f", C)
                + "C|" + Pressure + "|" + Rate);
    }
}
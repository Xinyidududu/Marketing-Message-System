import java.util.Scanner;
public class Debug {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter your name: ");
            String firstName = scanner.next();
            String lastName =scanner.next();
            scanner.nextLine();
            System.out.println("Enter your age: ");
            String age = scanner.nextLine();
            System.out.println("Enter your position: ");
            String job = scanner.nextLine();

            System.out.printf(firstName + " " + lastName + "\nAge: " + age + "\nOccupation: " + job);

        }
    }



import java.util.Scanner;


public class CheckIn {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Student Full Name:");
        String firstName = scan.next();
        String lastName = scan.next();
        scan.nextLine();
        System.out.println(lastName);
        System.out.println("Enter Student Mobile Number:");
        String phoneNumber = scan.nextLine();
        System.out.println("Enter Student ID Number (10 digits):");
        String idNumber = scan.nextLine();
        System.out.println("Enter Insurance Provider Name:");
        String insureName = scan.nextLine();
        System.out.println("Enter Time of Day:");
        String time = scan.nextLine();
        System.out.println("Enter Body Temperature (In F):");
        double temp = scan.nextDouble();
        scan.nextLine();
        System.out.println("Enter Blood Pressure:");
        String bloodPre = scan.nextLine();
        System.out.println("Enter Heart Rate:");
        String heartRate = scan.nextLine();

        String firstThree = phoneNumber.substring(0, 3);
        int oneThree = Integer.parseInt(firstThree);
        String secondThree = phoneNumber.substring(4, 7);
        int twoThree = Integer.parseInt(secondThree);
        String firstFour = phoneNumber.substring(8, 12);
        int oneFour = Integer.parseInt(firstFour);

        int totalMobile = oneFour + twoThree + oneThree;

        // int blank = firstName.indexOf(" ");
        //String upperName = firstName.substring(0, blank);


        String keepID = idNumber.substring(7, 10);
        char firstChar = insureName.charAt(0);
        char secondChar = insureName.charAt(1);
        int takeChar = firstChar;
        int takeChar2 = secondChar;


        double cDegree = (temp - 32) * (5 / 9.0);
        int hour = Integer.parseInt(time.substring(0, 2));
        String min = time.substring(2, 4);
        int result = hour % 12;


        System.out.printf("Code: " + firstName.toUpperCase() + "|" + totalMobile + "|" + keepID + "|" + takeChar + takeChar2 + "\nTime: %02d:%s", result, min);
        System.out.printf("\nVitals: %.2fF|%.2fC|%s|%s ", temp, cDegree, bloodPre, heartRate);

    }

}

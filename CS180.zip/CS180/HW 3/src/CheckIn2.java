import java.util.Scanner;

/**
 * A business card generator based on given user information.
 *
 * <p>Purdue University -- CS18000 -- Spring 2023</p>
 *
 * @author Purdue CS
 * @version January 26, 2023
 */

public class CheckIn2 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter Student Full Name:");
        String firstName = scan.next();
        String lastName = scan.nextLine();
        // scan.nextLine();
        //System.out.println(firstName + lastName);
        System.out.println("Enter Student Mobile Number:");
        String phoneNumber = scan.nextLine();
        //System.out.println(phoneNumber);
        System.out.println("Enter Student ID Number (10 digits):");
        String idNumber = scan.nextLine();
        //System.out.println(idNumber);
        System.out.println("Enter Insurance Provider Name:");
        String insureName = scan.nextLine();
        // System.out.println(insureName);
        System.out.println("Enter Time of Day:");
        String time = scan.nextLine();
        //System.out.println(time);
        System.out.println("Enter Body Temperature (In F):");
        String temp = scan.nextLine();
        //System.out.println(temp);
        System.out.println("Enter Blood Pressure:");
        String bloodPre = scan.nextLine();
        //System.out.println(bloodPre);
        System.out.println("Enter Heart Rate:");
        String heartRate = scan.nextLine();
        //System.out.println(heartRate);

        String firstThree = phoneNumber.substring(0, 3);
        int oneThree = Integer.parseInt(firstThree);
        String secondThree = phoneNumber.substring(4, 7);
        int twoThree = Integer.parseInt(secondThree);
        String firstFour = phoneNumber.substring(8, 12);
        int oneFour = Integer.parseInt(firstFour);

        int totalMobile = oneFour + twoThree + oneThree;

        String keepID = idNumber.substring(7, 10);
        char firstChar = insureName.charAt(0);
        char secondChar = insureName.charAt(1);
        int takeChar = firstChar;
        int takeChar2 = secondChar;

        double temp1 = Double.parseDouble(temp);
        double cDegree = (temp1 - 32) * (5 / 9.0);
        int hour = Integer.parseInt(time.substring(0, 2));
        String min = time.substring(2, 4);
        int result = hour % 12;


        System.out.printf("Code: " + firstName.toUpperCase() +
                        "|" + totalMobile + "|" + keepID +
                        "|"
                        + takeChar + takeChar2 + "\nTime: %02d:%s",
                result, min);
        System.out.printf("\nVitals: %.2fF|%.2fC|%s|%s ",
                temp1, cDegree, bloodPre, heartRate);

    }

}


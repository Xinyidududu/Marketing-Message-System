import java.util.Scanner;
/**
 * A program;
 *
 * <p>Purdue University -- CS18000 -- Spring 2023</p>
 *
 * @author Purdue CS
 * @version 2, 18, 2023
 */
public class CreditCardCalculator {
    public static final String WELCOME_MESSAGE = "Welcome to the Credit Card Calculator!";
    public static final String MENU = "Menu";
    public static final String QUIT_OPTION = "0. Quit";
    public static final String ADD_OPTION = "1. Add a card";
    public static final String RATE_PROMPT = "Enter the annual interest rate:";
    public static final String BALANCE_PROMPT = "Enter the balance:";
    public static final String PAYMENT_PROMPT = "Enter the monthly payment:";
    public static final String MODIFY_OPTION = "1. Modify card";
    public static final String PAYOFF_OPTION = "2. Calculate Payoff";
    public static final String CALCULATION_OPTION = "Would you like to print the payoff calculations?";
    public static final String CALCULATION_DECISION = "1. Yes\n2. No";
    public static final String CALCULATION_RESULT = "Months until payoff: %d";
    public static final String ERROR_MESSAGE = "Error! Invalid input.";
    public static final String GOODBYE_MESSAGE = "Thank you!";


    public static void main(String[] args) {
        boolean startManuOne = true;
        boolean startManuTwo = true;
        Scanner scan = new Scanner(System.in);
        System.out.println(WELCOME_MESSAGE);
        do {
            //print manu 1
            System.out.println(MENU);
            System.out.println(QUIT_OPTION);
            System.out.println(ADD_OPTION);
            int manuOneOption = scan.nextInt();

            if (manuOneOption == 0) {
                System.out.println(GOODBYE_MESSAGE);
                startManuOne = false;
            } else if (manuOneOption == 1) {

                System.out.println(RATE_PROMPT);
                double cardRate = scan.nextDouble();
                System.out.println(BALANCE_PROMPT);
                double cardBalance = scan.nextDouble();
                System.out.println(PAYMENT_PROMPT);
                double cardPayment = scan.nextDouble();
                Card card = new Card(cardRate, cardBalance, cardPayment);
                System.out.println(card);
                //move to print manu 2
                do {
                    System.out.println(MENU);
                    System.out.println(QUIT_OPTION);
                    System.out.println(MODIFY_OPTION);
                    System.out.println(PAYOFF_OPTION);
                    int manuTwoOption = scan.nextInt();

                    if (manuTwoOption == 0) {
                        System.out.println(GOODBYE_MESSAGE);
                        startManuTwo = false;
                        startManuOne = false;
                        //modify card
                    } else if (manuTwoOption == 1) {
                        System.out.println(RATE_PROMPT);
                        card.setRate(scan.nextDouble());
                        System.out.println(BALANCE_PROMPT);
                        card.setBalance(scan.nextDouble());
                        System.out.println(PAYMENT_PROMPT);
                        card.setMonthlyPayment(scan.nextDouble());

                        System.out.println(card);
                    } else if (manuTwoOption == 2) {
                        System.out.println(CALCULATION_OPTION);
                        System.out.println(CALCULATION_DECISION);
                        int manuThreeOption = scan.nextInt();

                        //move to manu 3
                        //print chart
                        if (manuThreeOption == 1) {
                            int index = card.calculatePayoff(true);
                            if (index == -1) {
                                System.out.println("Error: Impossible to payoff balance under these conditions");
                            } else {
                                System.out.printf(CALCULATION_RESULT + "\n", index);
                            }
                            //not print chart
                        } else if (manuThreeOption == 2) {
                            int index = card.calculatePayoff(false);
                            if (index == -1) {
                                System.out.println("Error: Impossible to payoff balance under these conditions");
                            } else {
                                System.out.printf(CALCULATION_RESULT + "\n", index);
                            }
                        }
                    } else {
                        System.out.println(ERROR_MESSAGE);
                    }


                } while (startManuTwo);
            } else {
                System.out.println(ERROR_MESSAGE);
            }


        } while (startManuOne);
    }
}
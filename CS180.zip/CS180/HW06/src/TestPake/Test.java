package TestPake;

public class Test {
    private int a;
    private int b;
    private double c;

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    public Test(int a, int b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}

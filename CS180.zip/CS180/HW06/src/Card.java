public class Card {
    private double rate;
    private double balance;
    private double monthlyPayment;

    public Card(double rate, double balance, double monthlyPayment) {
        this.rate = rate;
        this.balance = balance;
        this.monthlyPayment = monthlyPayment;
    }


    public double getRate() {
        return rate;
    }

    public double getBalance() {
        return balance;
    }

    public double getMonthlyPayment() {
        return monthlyPayment;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setMonthlyPayment(double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    public int calculatePayoff(boolean output) {
        int month = 0;
        double temp;
        boolean startCalculate = true;
        double monthlyInterestRate;
        double monthlyInterestCharge = 0;
        double monthlyPrinciplePayment;
        double totalInterestCharge = 0;
        while (startCalculate) {

            if (balance > 0) {
                monthlyInterestRate = rate / 12;
                monthlyInterestCharge = monthlyInterestRate * balance;
                monthlyPrinciplePayment = monthlyPayment - monthlyInterestCharge;
                temp = balance;
                balance = balance - monthlyPrinciplePayment;
                if (monthlyPayment < monthlyInterestCharge) {
                    month = -1;
                    return month;
                }
                if (balance <= 0) {
                    balance = 0;
                }
                totalInterestCharge = totalInterestCharge + monthlyInterestCharge;
                month++;
                if (output) {
                    if (balance != 0) {
                        System.out.printf("Payment: %d - Principal: %.2f - Interest: %.2f - Remaining Balance: %.2f\n",
                                month, monthlyPrinciplePayment, monthlyInterestCharge, balance);
                    } else if (balance == 0) {
                        System.out.printf("Payment: %d - Principal: %.2f - Interest: %.2f - Remaining Balance: %.2f\n",
                                month, temp, monthlyInterestCharge, balance);
                    }
                    if (balance == 0) {
                        System.out.printf("Total Interest Paid: %.2f\n", totalInterestCharge);
                    }
                } //else {
                //return month;
                //}
            }
            /*if (monthlyPayment < monthlyInterestCharge) {
                System.out.println("Error: Impossible to payoff balance under these conditions");
                month = -1;
                startCalculate = false;
                return month;
            }*/
            if (balance <= 0) {
                startCalculate = false;
            }
        }
        return month;
    }

    public String toString() {
        return String.format("Rate: %.2f - Balance: %.2f - Payment: %.2f", rate, balance, monthlyPayment);
    }

}

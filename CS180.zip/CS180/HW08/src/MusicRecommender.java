import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS
 * @version June 13, 2022
 */
public class MusicRecommender {
    private String musicListFileName;
    private ArrayList<Music> music;

    public MusicRecommender(String musicListFileName) throws FileNotFoundException, MusicFileFormatException {
        this.musicListFileName = musicListFileName;
        this.music = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new FileReader(musicListFileName));
            while (scanner.hasNextLine()) {
                String musicInfoLine = scanner.nextLine();
                //System.out.println(musicInfoLine);
                Music newMusic = parseMusic(musicInfoLine);
                music.add(newMusic);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException("Either musicList or musicProfile file does not exist.");
        } catch (MusicFileFormatException e) {
            throw new MusicFileFormatException(
                    "There is a malformed line in either of musicList or musicProfile file.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Music parseMusic(String musicInfoLine) throws MusicFileFormatException {
        String[] musicInfoArray = musicInfoLine.split(" ");
        if (musicInfoArray.length != 5) {
            throw new MusicFileFormatException("One of the lines of the music list file is malformed!");
        }
        try {
            String track = musicInfoArray[0].replaceAll("_", " ");
            String artist = musicInfoArray[1].replaceAll("_", " ");
            String genre = musicInfoArray[2].replaceAll("_", " ");
            int bpm = Integer.parseInt(musicInfoArray[3]);
            int popular = Integer.parseInt(musicInfoArray[4]);
            return new Music(track, artist, genre, bpm, popular);
        } catch (NumberFormatException e) {
            throw new MusicFileFormatException("One of the lines of the music list file is malformed!");
        }
    }

    public ArrayList<Music> searchArtists(MusicProfile musicProfile) throws NoRecommendationException {
        String artName = musicProfile.getPreferredArtist().toLowerCase();
        ArrayList<Music> sb = new ArrayList<>();
        for (int i = 0; i < music.size(); i++) {
            String curName = music.get(i).getArtist().toLowerCase();
            if (curName.contains(artName)) {
                String trackName = music.get(i).getTrack();
                String artName2 = music.get(i).getArtist();
                String songGenre = music.get(i).getGenre();
                int songBPM = music.get(i).getBPM();
                music.get(i).setPopularity(music.get(i).getPopularity() + 1);
                Music music2 = new Music(trackName, artName2, songGenre, songBPM, music.get(i).getPopularity());
                sb.add(music2);
            }
        }
        if (sb.size() == 0) {
            throw new NoRecommendationException("No music by your preferred artist is in the list!");
        }
        return sb;
    }

    public Music genreBasedRecommendation(MusicProfile musicProfile) throws NoRecommendationException {
        Music music1 = null;
        ArrayList<Music> musicList = new ArrayList<>();
        String genreName = musicProfile.getPreferredGenre().toLowerCase();
        for (int i = 0; i < music.size(); i++) {
            String curName = music.get(i).getGenre().toLowerCase();
            if (curName.contains(genreName)) {
                String tracName = music.get(i).getTrack();
                String artName = music.get(i).getArtist();
                String genreName2 = music.get(i).getGenre();
                int songBPM = music.get(i).getBPM();
                //music.get(i).setPopularity(music.get(i).getPopularity() + 1);
                music1 = new Music(tracName, artName, genreName2, songBPM, music.get(i).getPopularity());
                musicList.add(music.get(i));
            }
        }
        if (musicList.size() > 1) {
            int biggest = 0;
            int index = 0;
            if (musicProfile.isLikePopular()) {
                for (int j = 0; j < musicList.size(); j++) {
                    //int biggest = music.get(0).getPopularity();
                    if (musicList.get(j).getPopularity() > biggest) {
                        biggest = musicList.get(j).getPopularity();
                        //int biggestPoint = musicList.indexOf(biggest);
                        index = j;
                    }
                }
                musicList.get(index).setPopularity(biggest + 1);
                music1 = new Music(musicList.get(index).getTrack(),
                        musicList.get(index).getArtist(),
                        musicList.get(index).getGenre(),
                        musicList.get(index).getBPM(),
                        musicList.get(index).getPopularity());
            } else if (!musicProfile.isLikePopular()) {
                int smallest = musicList.get(0).getPopularity();
                int index2 = 0;
                for (int k = 0; k < musicList.size(); k++) {
                    //int smallest = musicList.get(0).getPopularity();
                    if (musicList.get(k).getPopularity() < smallest) {
                        smallest = musicList.get(k).getPopularity();
                        //int smallestPoint = musicList.indexOf(smallest);
                        index2 = k;
                    }
                }
                musicList.get(index2).setPopularity(smallest + 1);
                music1 = new Music(musicList.get(index).getTrack(),
                        musicList.get(index2).getArtist(),
                        musicList.get(index2).getGenre(),
                        musicList.get(index2).getBPM(),
                        musicList.get(index2).getPopularity());
            }
        }
        if (musicList.size() == 0) {
            throw new NoRecommendationException("There was no music with your preferred genre!");
        }
        return music1;
    }

    public Music BPMBasedRecommendation(MusicProfile musicProfile) throws NoRecommendationException {
        int preferBPM = musicProfile.getPreferredBPM();
        ArrayList<Music> musicList = new ArrayList<>();
        int smallestDiff = Math.abs(music.get(0).getBPM() - preferBPM);
        int diff;
        int checkAgain;
        ArrayList<Music> index = new ArrayList<>();
        for (int i = 0; i < music.size(); i++) {
            diff = Math.abs(music.get(i).getBPM() - preferBPM);
            if (diff < smallestDiff) {
                smallestDiff = diff;
            }
        }
        if (smallestDiff > 20) {
            throw new NoRecommendationException("There was no music with your preferred BPM!");
        }
        for (int i = 0; i < music.size(); i++) {
            checkAgain = Math.abs(music.get(i).getBPM() - preferBPM);
            if (checkAgain == smallestDiff) {
                Music sample = new Music(music.get(i).getTrack(),
                        music.get(i).getArtist(),
                        music.get(i).getGenre(),
                        music.get(i).getBPM(),
                        music.get(i).getPopularity());
                index.add(sample);
            }
        }
        Music music1 = null;
        if (index.size() > 1) {
            if (musicProfile.isLikePopular()) {
                for (int j = 0; j < index.size(); j++) {
                    int biggest = music.get(0).getPopularity();
                    if (music.get(j).getPopularity() > biggest) {
                        biggest = music.get(j).getPopularity();
                        //int biggestPoint = music.indexOf(biggest);
                        //int songPopular = music.get(index.get(biggestPoint)).getPopularity();
                        //music.get(biggestPoint).setPopularity(songPopular + 1);
                        music.get(j).setPopularity(biggest + 1);
                        music1 = new Music(music.get(j).getTrack(),
                                music.get(j).getArtist(),
                                music.get(j).getGenre(),
                                music.get(j).getBPM(),
                                music.get(j).getPopularity());
                        musicList.add(music1);
                    }
                }
            } else if (!musicProfile.isLikePopular()) {
                for (int k = 0; k < index.size(); k++) {
                    int smallest = music.get(0).getPopularity();
                    if (music.get(k).getPopularity() < smallest) {
                        smallest = music.get(k).getPopularity();
                        //int smallestPoint = music.indexOf(smallest);
                        //int songPopular = music.get(index.get(smallestPoint)).getPopularity();
                        //music.get(smallestPoint).setPopularity(songPopular + 1);
                        music.get(k).setPopularity(smallest + 1);
                        music1 = new Music(music.get(k).getTrack(),
                                music.get(k).getArtist(),
                                music.get(k).getGenre(),
                                music.get(k).getBPM(),
                                music.get(k).getPopularity());
                        musicList.add(music1);
                    }
                }
            }
        } else if (index.size() == 1) {
            int songPopular = index.get(0).getPopularity();
            index.get(0).setPopularity(songPopular + 1);
            music1 = new Music(index.get(0).getTrack(),
                    index.get(0).getArtist(), index.get(0).getGenre()
                    , index.get(0).getBPM(), index.get(0).getPopularity());
            musicList.add(music1);

        }
        if (musicList.size() == 0) {
            throw new NoRecommendationException("There was no music with your preferred BPM!");
        }
        return music1;
    }

    public Music getMostPopularMusic() {
        int mostPopular = music.get(0).getPopularity();
        int index = 0;
        for (int i = 0; i < music.size(); i++) {
            if (music.get(i).getPopularity() > mostPopular) {
                mostPopular = music.get(i).getPopularity();
                index = i;
            }
        }
        int songPopular = music.get(index).getPopularity();
        music.get(index).setPopularity(songPopular + 1);
        return new Music(music.get(index).getTrack(), music.get(index).getArtist(), music.get(index).getGenre()
                , music.get(index).getBPM(), music.get(index).getPopularity());
    }

    public void saveMusicList() {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(musicListFileName);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        PrintWriter pw = new PrintWriter(fos);
        for (Music value : music) {
            String newName = value.getTrack().replaceAll(" ", "_");
            String newArt = value.getArtist().replaceAll(" ", "_");
            String newGenre = value.getGenre().replaceAll(" ", "_");
            int newBPM = value.getBPM();
            int changePopular = value.getPopularity();
            String all = newName + " " + newArt + " " + newGenre + " " + newBPM + " " + changePopular + "\n";
            pw.write(all);
        }
        pw.close();

    }

}

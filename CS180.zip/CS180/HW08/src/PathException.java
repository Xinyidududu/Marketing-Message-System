public class PathException extends Exception {
    public PathException(String errorMessage) {
        super(errorMessage);
    }
    public PathException() {
        super();
    }
}

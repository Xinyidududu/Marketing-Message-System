import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 * A program that reads names from a text file, sorts them, then writes them to another text file.
 *
 * <p>Purdue University -- CS18000 -- Summer 2022</p>
 *
 * @author Purdue CS 
 * @version June 13, 2022
 */
public class SortNames {
    public static ArrayList<String> readFile(String fileName) throws FileNotFoundException {
        ArrayList<String> list = new ArrayList<>();
        FileReader fr = new FileReader(fileName);
        BufferedReader bfr = new BufferedReader(fr);
        String line = null;
        try {
            line = bfr.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (line != null) {
            list.add(line);
            try {
                line = bfr.readLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        try {
            bfr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public static void writeFile(String fileName, ArrayList<String> names) throws FileNotFoundException  {
        FileOutputStream fos = new FileOutputStream(fileName,true);
        PrintWriter pw = new PrintWriter(fos);
        for (String name : names) {
            pw.println(name);
        }
        pw.close();


    }

    public static void main(String[] args) {
        ArrayList<String> names;
        System.out.println("Enter filename with unsorted names");
        Scanner sc = new Scanner(System.in);
        String filename = sc.nextLine();
        try {
            names = readFile(filename);
            Collections.sort(names);
            writeFile("sorted_names.txt", names);
        } catch (IOException e) {
            System.out.println("File not found!");
            return;
        }
        System.out.println("Sorted names written to sorted_names.txt");
    }
}

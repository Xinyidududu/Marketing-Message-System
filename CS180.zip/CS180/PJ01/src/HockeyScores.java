import java.util.Scanner;

/**
 * A simple HockeyScores class
 *
 * @author Purdue CS
 * @version 07/03/2021
 */
public class HockeyScores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome!");
        System.out.println("Enter the name of team 1.");
        String teamOne = scanner.nextLine();
        System.out.println("Enter the name of team 2.");
        String teamTwo = scanner.nextLine();
        System.out.println("Enter hockey scores for seven games.");
        String scores = scanner.nextLine();
        System.out.println("Enter the number of power play goals for both teams in each game.");
        String powerPlay = scanner.nextLine();
        scanner.close();

        // The values of each of the scores are defined below, you should use these int variables
        /* The string has 7 scores so the format of the string is
         * scoreOneTeamOne-scoreOneTeamTwo,scoreTwoTeamOne-scoreTwoTeamTwo,scoreThreeTeamOne-scoreThreeTeamTwo,
         * ...
         */
        int currentScoreIndex = 0;
        int scoreOneTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreOneTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreTwoTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreTwoTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreThreeTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreThreeTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreFourTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreFourTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreFiveTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreFiveTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreSixTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreSixTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreSevenTeamOne = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));
        currentScoreIndex += 3;
        int scoreSevenTeamTwo = Integer.parseInt(scores.substring(currentScoreIndex, currentScoreIndex + 2));

        // The values of each of the power play goals are defined below, you should use these int variables
        /* The string has the number of power play goals listed for both teams in each of the seven games so
         * the format of the string is
         * powerPlayOneTeamOne-powerPlayOneTeamTwo,powerPlayTwoTeamOne-powerPlayTwoTeamTwo,powerPlayThreeTeamOne-powerPlayThreeTeamTwo,
         * ...
         */
        int currentPowerPlayIndex = 0;
        int powerPlayOneTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayOneTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayTwoTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayTwoTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayThreeTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayThreeTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayFourTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayFourTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayFiveTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlayFiveTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlaySixTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlaySixTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlaySevenTeamOne = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));
        currentPowerPlayIndex += 3;
        int powerPlaySevenTeamTwo = Integer.parseInt(powerPlay.substring(currentPowerPlayIndex,
                currentPowerPlayIndex + 2));

        //TODO


        //The penguins won the series by a score of 5-2
        int scoreWinCountOne = 0;
        int scoreWinCountTwo = 0;
        int scoreWinOne;
        int scoreWinTwo;
        int powerWinOne;
        int powerWinTwo;
        int standOne;
        int standTwo;
        if (scoreOneTeamOne > scoreOneTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreTwoTeamOne > scoreTwoTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreThreeTeamOne > scoreThreeTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreFourTeamOne > scoreFourTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreFiveTeamOne > scoreFiveTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreSixTeamOne > scoreSixTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreSevenTeamOne > scoreSevenTeamTwo) {
            scoreWinCountOne += 1;
        } else {
            scoreWinCountTwo += 1;
        }
        if (scoreWinCountOne > scoreWinCountTwo) {
            System.out.println("The " + teamOne + " won the series by a score of "
                    + scoreWinCountOne + "-" + scoreWinCountTwo);
        } else {
            System.out.println("The " + teamTwo + " won the series by a score of "
                    + scoreWinCountTwo + "-" + scoreWinCountOne);
        }
        //The penguins scored 23 total goals
        //The red wings scored 22 total goals
        scoreWinOne = scoreOneTeamOne + scoreTwoTeamOne + scoreThreeTeamOne + scoreFourTeamOne + scoreFiveTeamOne +
                scoreSixTeamOne + scoreSevenTeamOne;
        scoreWinTwo = scoreOneTeamTwo + scoreTwoTeamTwo + scoreThreeTeamTwo + scoreFourTeamTwo + scoreFiveTeamTwo +
                scoreSixTeamTwo + scoreSevenTeamTwo;
        System.out.println("The " + teamOne + " scored " + scoreWinOne + " total goals");
        System.out.println("The " + teamTwo + " scored " + scoreWinTwo + " total goals");

        //The penguins scored 8 power play goals
        //The red wings scored 8 power play goals
        powerWinOne = powerPlayOneTeamOne + powerPlayTwoTeamOne + powerPlayThreeTeamOne + powerPlayFourTeamOne
                + powerPlayFiveTeamOne + powerPlaySixTeamOne + powerPlaySevenTeamOne;
        powerWinTwo = powerPlayOneTeamTwo + powerPlayTwoTeamTwo + powerPlayThreeTeamTwo + powerPlayFourTeamTwo
                + powerPlayFiveTeamTwo + powerPlaySixTeamTwo + powerPlaySevenTeamTwo;

        System.out.println("The " + teamOne + " scored " + powerWinOne + " power play goals");
        System.out.println("The " + teamTwo + " scored " + powerWinTwo + " power play goals");

        //The penguins scored 15 standard goals
        //The red wings scored 14 standard goals
        standOne = scoreWinOne - powerWinOne;
        standTwo = scoreWinTwo - powerWinTwo;
        System.out.println("The " + teamOne + " scored " + standOne + " standard goals");
        System.out.println("The " + teamTwo + " scored " + standTwo + " standard goals");

        //The penguins recorded 2 shutouts
        //The red wings recorded 0 shutouts
        int out1 = 0;
        int out2 = 0;
        if (scoreOneTeamOne == 0)
            out1 += 1;
        if (scoreTwoTeamOne == 0)
            out1 += 1;
        if (scoreThreeTeamOne == 0)
            out1 += 1;
        if (scoreFourTeamOne == 0)
            out1 += 1;
        if (scoreFiveTeamOne == 0)
            out1 += 1;
        if (scoreSixTeamOne == 0)
            out1 += 1;
        if (scoreSevenTeamOne == 0)
            out1 += 1;


        if (scoreOneTeamTwo == 0)
            out2 += 1;
        if (scoreTwoTeamTwo == 0)
            out2 += 1;
        if (scoreThreeTeamTwo == 0)
            out2 += 1;
        if (scoreFourTeamTwo == 0)
            out2 += 1;
        if (scoreFiveTeamTwo == 0)
            out2 += 1;
        if (scoreSixTeamTwo == 0)
            out2 += 1;
        if (scoreSevenTeamTwo == 0)
            out2 += 1;

        if (out2 == 1) {
            System.out.println("The " + teamOne + " recorded " + out2 + " shutout");
        } else {
            System.out.println("The " + teamOne + " recorded " + out2 + " shutouts");
        }

        if (out1 == 1) {
            System.out.println("The " + teamTwo + " recorded " + out1 + " shutout");
        } else {
            System.out.println("The " + teamTwo + " recorded " + out1 + " shutouts");
        }

        //The maximum number of goals scored was 9 by the red wings in game 2
        int max1 = 0;
        int max2 = 0;
        int groupNum = 0;
        int groupNum2 = 0;

        if (max1 > scoreOneTeamOne) {
            max1 = 0;

        } else if (max1 < scoreOneTeamOne) {
            max1 = scoreOneTeamOne;
            groupNum = 1;
        }
        if (max1 < scoreTwoTeamOne) {
            max1 = scoreTwoTeamOne;
            groupNum = 2;
        }
        if (max1 < scoreThreeTeamOne) {
            max1 = scoreThreeTeamOne;
            groupNum = 3;
        }
        if (max1 < scoreFourTeamOne) {
            max1 = scoreFourTeamOne;
            groupNum = 4;
        }
        if (max1 < scoreFiveTeamOne) {
            max1 = scoreFiveTeamOne;
            groupNum = 5;
        }
        if (max1 < scoreSixTeamOne) {
            max1 = scoreSixTeamOne;
            groupNum = 6;
        }
        if (max1 < scoreSevenTeamOne) {
            max1 = scoreSevenTeamOne;
            groupNum = 7;
        }


        if (max2 > scoreOneTeamTwo) {
            max2 = 0;

        } else if (max2 < scoreOneTeamTwo) {
            max2 = scoreOneTeamTwo;
            groupNum2 = 1;
        }
        if (max2 > scoreTwoTeamTwo) {
            max2 = scoreOneTeamTwo;
            groupNum2 = 1;
        } else if (max2 < scoreTwoTeamTwo) {
            max2 = scoreTwoTeamTwo;
            groupNum2 = 2;
        }

        if (max2 < scoreThreeTeamTwo) {
            max2 = scoreThreeTeamTwo;
            groupNum2 = 3;
        }

        if (max2 < scoreFourTeamTwo) {
            max2 = scoreFourTeamTwo;
            groupNum2 = 4;
        }

        if (max2 < scoreFiveTeamTwo) {
            max2 = scoreFiveTeamTwo;
            groupNum2 = 5;
        }

        if (max2 < scoreSixTeamTwo) {
            max2 = scoreSixTeamTwo;
            groupNum2 = 6;
        }


        if (max2 < scoreSevenTeamTwo) {
            max2 = scoreSevenTeamTwo;
            groupNum2 = 7;
        }

        // max1 = 9, game = 6; max2 = 9, game = 3;
        if (max1 > max2) {
            System.out.println("The maximum number of goals scored was " + max1 + " by the " + teamOne +
                    " in game " + groupNum);
        } else if (max1 < max2) {
            System.out.println("The maximum number of goals scored was " + max2 + " by the " + teamTwo +
                    " in game " + groupNum2);
        } else { // case max1 = max2
            if (groupNum < groupNum2) {
                System.out.println("The maximum number of goals scored was " + max1 + " by the " + teamOne +
                        " in game " + groupNum);
            } else {
                System.out.println("The maximum number of goals scored was " + max2 + " by the " + teamTwo +
                        " in game " + groupNum2);
            }

        }

    }
}







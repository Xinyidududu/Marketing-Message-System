package test;

public class pratice {

    public static void main(String[] args) {
        int val1 = 3;
        int val2 = 2;
        int val3 = 1;

        int max = 0;
        int maxIndex = 0;

        if (max < val1){
            //do somethings
        }

        if (max < val1) {
            max = val1;
            maxIndex = 1;
        }
        if (max < val2) {
            max = val2;
            maxIndex = 2;
        }

        if (max < val3) {
            max = val3;
            maxIndex = 3;
        }

        System.out.println("Max:" + max + "| maxIndex: " + maxIndex);
    }
}

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);

            System.out.println("What's your name?");
            String name = scanner.nextLine();

            System.out.println("How old are you?");
            int age = scanner.nextInt();
            scanner.nextLine(); // IMPORTANT!!

            System.out.println("Where are you from?");
            String placeOfOrigin = scanner.nextLine();

            System.out.println("What's your favorite letter of the alphabet?");
            char favoriteLetter = scanner.next().charAt(0);
            scanner.nextLine(); // IMPORTANT!!


            System.out.println("What's your favorite color?");
            String favoriteColor = scanner.nextLine();

            System.out.printf("Here's what you told us: Your name is %s. You're %d years old. You're " +
                            "from %s. Your favorite letter of the alphabet is %c. Your favorite color is %s" , name ,
                    age , placeOfOrigin , favoriteLetter , favoriteColor);
        }

    }

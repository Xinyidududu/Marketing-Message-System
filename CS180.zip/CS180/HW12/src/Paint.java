import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

/**
 * A program.
 *
 * <p>Purdue University -- CS18000 -- Spring 2023</p>
 *
 * @author Purdue CS
 * @version April 11, 2023
 */
public class Paint extends JComponent implements Runnable {
    private Image image;
    private Graphics2D graphics2D;
    private int curX;
    private int curY;
    private int oldX;
    private int oldY;
    private Color penClr;
    JButton clrButton;
    JButton fillButton;
    JButton eraseButton;
    JButton randomButton;
    JButton hexButton;
    JButton rgbButton;
    JTextField hexText;
    JTextField rText;
    JTextField gText;
    JTextField bText;
    Paint paint;


    public void setPen(Color color){
        graphics2D.setColor(color);
    }


    public void clear() {
        graphics2D.setPaint(Color.white);
        graphics2D.setBackground(Color.white);
        graphics2D.fillRect(0, 0, getSize().width, getSize().height);
        graphics2D.setPaint(Color.black);
        repaint();
        //bgClr = Color.white;
    }

    public void fill() {
        graphics2D.setBackground(graphics2D.getColor()); //maybe Problem?
        graphics2D.fillRect(0, 0, getSize().width, getSize().height);
        graphics2D.setPaint(Color.black);
        repaint();
    }

    public void erase() {
        if (image != null){
            graphics2D.setPaint(graphics2D.getBackground());
        }else {
            graphics2D.setPaint(Color.white);
        }
    }


    public Paint() {
        //graphics2D.setStroke(new BasicStroke(5));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                /* set oldX and oldY coordinates to beginning mouse press*/
                oldX = e.getX();
                oldY = e.getY();
            }
        });


        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                /* set current coordinates to where mouse is being dragged*/
                curX = e.getX();
                curY = e.getY();

                /* draw the line between old coordinates and new ones */
                graphics2D.drawLine(oldX, oldY, curX, curY);

                /* refresh frame and reset old coordinates */
                repaint();
                oldX = curX;
                oldY = curY;

            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Paint());
    }

    @Override
    public void run() {
        JFrame jFrame = new JFrame("Homework 12 Artwork");
        Container content = jFrame.getContentPane();
        content.setLayout(new BorderLayout());
        paint = new Paint();
        content.add(paint, BorderLayout.CENTER);
        content.add(paint);
        clrButton = new JButton("Clear");
        //clrButton.addActionListener(actionListener);
        fillButton = new JButton("Fill");
        //fillButton.addActionListener(actionListener);
        eraseButton = new JButton("Erase");
        //eraseButton.addActionListener(actionListener);
        randomButton = new JButton("Random");
        //randomButton.addActionListener(actionListener);
        hexButton = new JButton("Hex");
        //hexButton.addActionListener(actionListener);
        rgbButton = new JButton("RGB");
        //rgbButton.addActionListener(actionListener);
        hexText = new JTextField();
        hexText.setText("#"); // set default text to "#"
        hexText.setColumns(10); // set number of columns to 10
        rText = new JTextField();
        rText.setText("");
        rText.setColumns(5);
        gText = new JTextField();
        gText.setText("");
        gText.setColumns(5);
        bText = new JTextField();
        bText.setText("");
        bText.setColumns(5);
        JPanel panel = new JPanel();
        JPanel panel1 = new JPanel();
        panel.add(clrButton);
        panel.add(fillButton);
        panel.add(eraseButton);
        panel.add(randomButton);
        panel1.add(hexText);
        panel1.add(hexButton);
        panel1.add(rText);
        panel1.add(gText);
        panel1.add(bText);
        panel1.add(rgbButton);
        content.add(panel, BorderLayout.NORTH);
        content.add(panel1, BorderLayout.SOUTH);
        jFrame.setSize(600,500);
        jFrame.setLocationRelativeTo(null);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jFrame.setVisible(true);


        clrButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paint.clear();
                hexText.setText("#");
                rText.setText("");
                gText.setText("");
                bText.setText("");
            }
        });
        fillButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paint.fill();
                hexText.setText("#");
                rText.setText("");
                gText.setText("");
                bText.setText("");
            }
        });
        eraseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paint.erase();
            }
        });
        randomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Random rand = new Random();
                int r = rand.nextInt(256);
                int g = rand.nextInt(256);
                int b = rand.nextInt(256);
                penClr = new Color(r, g, b);
                paint.setPen(penClr);
                hexText.setText(String.format("#%02x%02x%02x", r, g, b));
                rText.setText(Integer.toString(r));
                gText.setText(Integer.toString(g));
                bText.setText(Integer.toString(b));
            }
        });
        hexButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String hexValue = hexText.getText();
                try {
                    // Parse the hex value and set the pen color
                    penClr = Color.decode(hexValue);
                    paint.setPen(penClr);
                    // Set the RGB values to the text fields
                    rText.setText(String.valueOf(penClr.getRed()));
                    gText.setText(String.valueOf(penClr.getGreen()));
                    bText.setText(String.valueOf(penClr.getBlue()));
                } catch (NumberFormatException ex) {
                    // Show an error message if the hex value is invalid
                    JOptionPane.showMessageDialog(null, "Not a valid Hex Value", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        rgbButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int r;
                int g;
                int b;
                try {
                    r = Integer.parseInt(rText.getText());
                } catch (NumberFormatException ex) {
                    r = 0;
                }

                try {
                    g = Integer.parseInt(gText.getText());
                } catch (NumberFormatException ex) {
                    g = 0;
                }

                try {
                    b = Integer.parseInt(bText.getText());
                } catch (NumberFormatException ex) {
                    b = 0;
                }
                if (rText.getText().isEmpty() && gText.getText().isEmpty() && bText.getText().isEmpty()) {
                    rText.setText("0");
                    gText.setText("0");
                    bText.setText("0");
                }
                try {
                    Color newColor = new Color(r, g, b);

                    // set the pen color to the new color
                    penClr = newColor;
                    paint.setPen(penClr);

                    // set the hex value to the new color
                    hexText.setText(String.format("#%02x%02x%02x", r, g, b));
//                    String hexValue = Integer.toHexString(newColor.getRGB() & 0xffffff);
//                    hexText.setText(hexValue.toUpperCase());

                    // set the r, g, and b text fields to the new color values
                    rText.setText(Integer.toString(newColor.getRed()));
                    gText.setText(Integer.toString(newColor.getGreen()));
                    bText.setText(Integer.toString(newColor.getBlue()));
                } catch (IllegalArgumentException ex) {
                    // show error message for invalid rgb values
                    JOptionPane.showMessageDialog(null, "Not a valid RGB Value", "Error"
                            , JOptionPane.ERROR_MESSAGE);
                }

            }

        });

    }

    protected void paintComponent(Graphics g) {
        if (image == null) {
            image = createImage(getSize().width, getSize().height);
            /* this lets us draw on the image (ie. the canvas)*/
            graphics2D = (Graphics2D) image.getGraphics();
            graphics2D.setStroke(new BasicStroke(5));
            /* gives us better rendering quality for the drawing lines */
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            /* set canvas to white with default paint color */
            graphics2D.setPaint(Color.white);
            graphics2D.setBackground(Color.white);
            graphics2D.fillRect(0, 0, getSize().width, getSize().height);
            graphics2D.setPaint(Color.black);
            repaint();
        }
        g.drawImage(image, 0, 0, null);

    }

}


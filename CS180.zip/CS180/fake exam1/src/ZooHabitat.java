import java.util.Objects;

public class ZooHabitat {
    private Animal animalOne;
    private Animal animalTwo;
    private Animal animalThree;

    public ZooHabitat(Animal animalOne, Animal animalTwo, Animal animalThree) {
        this.animalOne = animalOne;
        this.animalTwo = animalTwo;
        this.animalThree = animalThree;
    }

    public ZooHabitat(ZooHabitat zooHabitat) {
        this.animalOne = zooHabitat.animalOne;
        this.animalThree = zooHabitat.animalThree;
        this.animalTwo = zooHabitat.animalTwo;
    }

    public boolean addAnimal(Animal animal) {
        if (this.animalOne == null) {
            this.animalOne = animal;
            return true;
        } else if (this.animalTwo == null) {
            this.animalTwo = animal;
            return true;
        } else if (this.animalThree == null) {
            this.animalThree = animal;
            return true;
        }
        return false;

    }

    public boolean removeAnimal(Animal animal) {
        if (Objects.equals(this.animalOne.getName(), animal.getName()) &&
                Objects.equals(this.animalOne.getSpecies(), animal.getSpecies())
                && this.animalOne.getYear() == animal.getYear()) {
            this.animalOne = null;
            return true;
        }
        if (Objects.equals(this.animalThree.getName(), animal.getName()) &&
                Objects.equals(this.animalThree.getSpecies(), animal.getName())
                && this.animalThree.getYear() == animal.getYear()) {
            this.animalThree = null;
            return true;
        }
        if (Objects.equals(this.animalTwo.getName(), animal.getName()) &&
                Objects.equals(this.animalTwo.getSpecies(), animal.getName())
                && this.animalTwo.getYear() == animal.getYear()) {
            this.animalTwo = null;
            return true;
        }
        return false;
    }


    public int getAvailableSpace() {
        return 3 - this.getAnimalCount();
    }

    public int getAnimalCount() {
        int count = 0;
        if (this.animalOne != null) {
            count += 1;
        }
        if (this.animalTwo != null) {
            count += 1;
        }
        if (this.animalThree != null) {
            count += 1;
        }
        return count;
    }

    public double calculateTotalMaintenanceCost() {
        double totalCost = 0.0;
        if (this.animalOne != null) {
            totalCost += animalOne.getMaintenanceCost();
        }
        if (this.animalTwo != null) {
            totalCost += animalTwo.getMaintenanceCost();
        }
        if (this.animalThree != null) {
            totalCost += animalThree.getMaintenanceCost();
        }
        return totalCost;
    }

    public int getAverageAge() {
        int currentYear = 2023;
        int totalAges = 0;
        if (this.animalOne != null) {
            totalAges += currentYear - this.animalOne.getYear();
        }
        if (this.animalTwo != null) {
            totalAges += currentYear - this.animalTwo.getYear();
        }
        if (this.animalThree != null) {
            totalAges += currentYear - this.animalThree.getYear();
        }

        return totalAges / this.getAnimalCount();
    }
}

import java.util.Scanner;

public class ZooInfo {
    public static String INTRO = "Welcome to the ZooInfo program!";
    public static String NAME_PROMPT = "What is the animal's name?";
    public static String SPECIES_PROMPT = "What is the animal's species?";
    public static String COUNTRY_PROMPT = "Where is the animal from?";
    public static String BIRTH_PROMPT = "What year was the animal (in yyyy form) born?";
    public static String YEARS_AT_ZOO_PROMPT = "How many years has the animal been at the zoo?";
    public static String HABITAT_TYPE_PROMPT = "Does the the animal need to be kept in a tank, cage, or free-roam?";
    public static String WEATHER_PROMPT = "Does the animal prefer hot or cold weather?";
    public static String CARETAKER_NUMBER_PROMPT = "How many people regularly take care of the animal?";
    public static String ITH_PERSON_PROMPT = "What is the name of person number ";
    public static String FOOD_PROMPT = "How much food does the animal eat in a day?";

    public static void main(String[] args) {
        String careType = "";
        String preferTemp = "";
        String peopleName;
        String totalPeople = "";
        String newTotalPeople;
        String foodStatus = "";
        String birthYear = "";
        Scanner scan = new Scanner(System.in);
        System.out.println(INTRO);
        System.out.println(NAME_PROMPT);
        String animalName = scan.nextLine();

        System.out.println(SPECIES_PROMPT);
        String animalSpecies = scan.nextLine();

        System.out.println(COUNTRY_PROMPT);
        String animalCome = scan.nextLine();

        System.out.println(BIRTH_PROMPT);
        String year = scan.nextLine();

        System.out.println(YEARS_AT_ZOO_PROMPT);
        String yearBeHere = scan.nextLine();

        System.out.println(HABITAT_TYPE_PROMPT);
        String animalNeed = scan.nextLine();

        System.out.println(WEATHER_PROMPT);
        String animalTemp = scan.nextLine();

        System.out.println(CARETAKER_NUMBER_PROMPT);
        int peopleNumb = scan.nextInt();
        scan.nextLine();

        for (int i = 1; i <= peopleNumb; i++) {
            System.out.println(ITH_PERSON_PROMPT + i + " ?");
            peopleName = scan.nextLine();
            totalPeople = totalPeople + peopleName + ",";
        }
        System.out.println(FOOD_PROMPT);
        String food = scan.nextLine();
        int l = food.toUpperCase().indexOf("L");
        double foodWeight = Double.parseDouble(food.substring(0, l));

        char identifyName1 = animalSpecies.toUpperCase().charAt(0);
        char identifyName11 = animalSpecies.toUpperCase().charAt(animalSpecies.length() - 1);
        String identifyName2 = animalCome.toUpperCase().substring(0, 3);
        String totalIdentify = identifyName1 + "" + identifyName11 + identifyName2;
        //String birthYear = year.substring(2, 4);

        if (animalNeed.equalsIgnoreCase("tank")) {
            careType = "TK";
        } else if (animalNeed.equalsIgnoreCase("cage")) {
            careType = "CG";
        } else if (animalNeed.equalsIgnoreCase("free-roam")) {
            careType = "FR";

        }
        if (animalTemp.equalsIgnoreCase("hot")) {
            preferTemp = "H";
        } else if (animalTemp.equalsIgnoreCase("cold")) {
            preferTemp = "C";
        }

        if (foodWeight < 5) {
            foodStatus = "LITTLE";
        } else if (foodWeight >= 5 && foodWeight < 20) {
            foodStatus = "AVERAGE";
        } else if (foodWeight > 20) {
            foodStatus = "LOT";
        }
        if (year.equals("2000")) {
            birthYear = "0";
        } else {
            birthYear = year.substring(2, 4);
        }
        newTotalPeople = totalPeople.substring(0, totalPeople.length() - 1);
        System.out.println(animalName.toUpperCase() + "_" + totalIdentify + "_" + birthYear + "_" + yearBeHere
                + "_" + careType + "_" + preferTemp + "_" + "CARE{" + newTotalPeople + "}_" + foodStatus + ";");

    }

}

public enum Action {
    DECX, INCX, DECY, INCY, DECHP, INCHP
}

public class PlayerDriver {
    public static void main(String[] args) throws InterruptedException{
        Player player = new Player(0, 5000);
        Thread decX = new Thread(new PlayThread(player, Action.DECX));
        Thread incX = new Thread(new PlayThread(player, Action.INCX));
        Thread decY = new Thread(new PlayThread(player, Action.DECY));
        Thread incY = new Thread(new PlayThread(player, Action.INCY));
        Thread decHP = new Thread(new PlayThread(player, Action.DECHP));
        Thread incHP = new Thread(new PlayThread(player, Action.INCHP));
        decX.start();
        incX.start();
        decY.start();
        incY.start();
        decHP.start();
        incHP.start();

        decX.join();
        incX.join();
        decY.join();
        incY.join();
        decHP.join();
        incHP.join();
        player.printPlayer();
    }
}


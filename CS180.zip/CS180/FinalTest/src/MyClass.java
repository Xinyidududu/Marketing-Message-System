public class MyClass {

    public void myMethod() throws Exception {

        System.out.print("myMethod ");

        throw new Exception("exceptionMessage");

    }



    public MyClass() {

        System.out.print("Constructor ");

    }



    public static void main(String[] args) {

        System.out.print("main ");

        MyClass mc = new MyClass();

        try {

            mc.myMethod();

        } catch (Exception e) {

            System.out.print("exception ");

        }


        System.out.print("finish");

    }

}
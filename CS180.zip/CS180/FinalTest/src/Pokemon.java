public class Pokemon {


    public String toString() {

        return "Pokemon[?]";

    }

}
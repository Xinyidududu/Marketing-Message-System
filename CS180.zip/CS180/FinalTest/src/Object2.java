public class Object2 extends Object1 {

    protected String d(){

        return super.d();

    }

}



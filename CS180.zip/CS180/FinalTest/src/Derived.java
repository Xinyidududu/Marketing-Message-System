class Derived extends Base {

    public void show() {

        System.out.println("Derived show() called");

    }

}


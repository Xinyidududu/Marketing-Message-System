class Base {

    final public void show() {

        System.out.println("Base show() called");

    }

}

    enum Animal {

        CAT,

        DOG,

        RAT

    }


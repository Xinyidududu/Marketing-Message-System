class Test {

    public static void main(String[] args) {
        int x = 2;
        if ((x & 1) == 1){

        }

    }

}
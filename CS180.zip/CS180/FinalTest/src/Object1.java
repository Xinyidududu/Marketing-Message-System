public class Object1 {

    protected String d(){

        return "Hi";

    }

}
